unit Unit3;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics,
  Dialogs, StdCtrls, ExtCtrls,strbox3;

type

  { TForm2 }

  TForm2 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Label1: TLabel;
    Panel1: TPanel;
    Timer1: TTimer;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  private

  public

  end;

var
  Form2: TForm2;
  xSuspend: integer;
   const
     CaptionStr   = 'Timer will elapse in ... ';

implementation

{$R *.lfm}

{ TForm2 }

procedure TForm2.FormShow(Sender: TObject);
begin
  form2.top := screen.height div 3;
  form2.left := screen.Width div 3;
  xsuspend := 20;
   timer1.enabled := true;
end;

procedure TForm2.Button1Click(Sender: TObject);
begin
  timer1.enabled := false;
  form2.Hide;
end;

procedure TForm2.Button2Click(Sender: TObject);
var
  sl: tstringlist;
begin
  sl := tstringlist.create;
  executeCmdDetach('systemctl suspend',sl);
   form2.hide;
   timer1.Enabled := false;
end;

procedure TForm2.FormPaint(Sender: TObject);
//bprocedure TForm1.FormPaint(Sender: TObject);
var
  i, j, step, offset,x: Integer;
  lineColor: TColor;
begin
  // Set the background color to white (or any color)
  Canvas.Brush.Color := clMaroon;
  Canvas.FillRect(Rect(0, 0, Width, Height));

  // Define pattern parameters
  step := 20;           // Spacing between lines
  offset := step div 2;          // Offset for the second set of lines to create a grid
  lineColor := clOlive;  // Color of the hatch lines

  // Draw first set of diagonal lines (Top-Left to Bottom-Right)
  Canvas.Pen.Color := lineColor;
  Canvas.Pen.Width := 2;
 {for i := -Height to Width + Height do
  begin
    if odd(i) then
    Canvas.Line(i, 0, i + Height, Height);
  end;   }
          x := 0;
  // Draw second set of diagonal lines (Top-Right to Bottom-Left)
  // This creates the crosshatch effect
//  for i := 0 to width do //+ offset to Width + offset do
     for i := 0 to form2.Width div 10  do
begin
    x := x + 10;
      canvas.line(x,0,500+x,500);
  //  Canvas.Line(Width - x, 0, Width-x, Height);
    end;
  {for i := -Height to Width + Height do
  begin
    if odd(i) then
    Canvas.Line(Width - i, 0, i - Width, Height);
  end;  }
end;
//

procedure TForm2.Timer1Timer(Sender: TObject);
var
  sl: tstringlist;
begin
  sl := tstringlist.create;
  panel1.Caption := captionStr+inttostr(xsuspend);
  xsuspend := xsuspend - 1;
  if xsuspend = 0 then
    begin
   executeCmdDetach('systemctl suspend',sl);
   form2.hide;
   timer1.Enabled := false;
    end;

//  label1.caption := timetostr(now);
end;

end.

