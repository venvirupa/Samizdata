unit STRBOX2;
{$N+}
{.$DEFINE OLDDELPHI}
interface

uses
  MathBox, SysUtils, Winprocs, WinTypes,math;

const
  CR = #13#10;

type
  Str12 = string[12];
  DirStr = string[67];
  PathStr = string[79];
  NameStr = string[8];
  ExtStr = string[4];

function Address2Str(Addr : Pointer) : string;
function AddBackSlash(S: string): string;
function Rot13(sinput: string):  string;
function CleanString(S: string): string;
function ConvertSpacesToZeros(S: string): string;
function ConvertSpacesToUnderlines(S: string): string;
function ConvertSpacesToNothing(S: string): string;
function GetNumberOfWords(LineofTxt: string): integer;
//get word from positon x
function GetWordFromStringAtX(s: string;x: integer): string;
function GetLocationOfWord(LineofTxt: string; caretx: integer): integer;

function GetFirstWord(S: string): string;
function GetFirstToken(S: string; Token: Char; maxInt: integer): string;
function GetHexWord(w: Word): string;
function GetLastToken(S: string; Token: Char): string;
function GetLastWord(S: string): string;
function GetLast3chars(S: string): string;
{$ifdef OLDDELPHI}
function GetLogicalAddr(A: Pointer): Pointer;
{$endif}
function GetTodayName(Pre, Ext: string): string;
function GetTodaysDate: string;
function GetTimeString: string;
function GetTimeFormat: string;
function IsNumber(Ch: Char): Boolean;
function isAlpha(c : char ) : boolean;
function LeftSet(src: string; Width:Integer; var Trunc: Boolean): string;
function ReplaceChars(S: string; OldCh, NewCh: Char): string;
function RightCharSet(Src: string; Width: Integer;
                      Ch: Char; var Trunc: Boolean): string;
function RemoveFirstWord(var S : string) : string;    overload
function RemoveFirstWord(var S : widestring) : widestring;  overload

function ReplaceStringOld(NewStr, ReplaceStr, Data: string): string;
function ReplaceString(NewStr, ReplaceStr, Data: string): string;
function ReplaceString2(NewStr, ReplaceStr, Data: string): string;

function ReverseStr(S: string): string;
function Shorten(S: string; Cut: Integer): string;
procedure SplitDirName(Path : PathStr; var Dir: DirStr; var WName: Str12);
function StripBlanks(S: string): string;
function StripEndChars(S: string; Ch: Char): string;
function StripNullChars(s: string): string;
function StripFirstWord(S : string; x: string) : string;
function StripHTMLTag(S : string; x: string) : string;
function StripFirstToken(S: string; Ch: Char; smalllimit: integer): string;
function StripFrontChars(S: string; Ch: Char): string;
function StripFromFront(S: string; Len: Integer): string;

function StripFromBack(S: string; Len: Integer): string;

function StripLastToken(S: string; Token: Char): string;
function GetURLFromString(S: string): string;
function Q_StrHashKey(const S: string): LongWord;
function Q_StrHashPassEnc(const s: string): string;
function Q_StrHashPassDec(const s: string): string;
function RotateBy(AStr: String; const ARotate: Integer = 47): String;

{$ifdef OldDelphi}
procedure SetLength(var S: string; i: Integer);
{$endif}

implementation
uses
  Classes,unit1;

{$ifdef OldDelphi}
procedure SetLength(var S: string; i: Integer);
begin
  S[0] := Chr(i);
end;
{$endif}

function StripNullChars(S: string): string;
var
  Temp: string;
begin
  Temp := ''; 
  if Length(S) <> 0 then begin
    Temp := StripFrontChars(S, #0);
    Temp := StripBlanks(Temp);
  end;
  StripNullChars := Temp;
end;

function GetURLFromString(S: string): string;
begin

end;
function ConvertSpacesToUnderlines(S: string): string;
//var x: string;

begin
 // S := '   123.5';
  { Convert spaces to _ }
  while Pos(' ', S) > 0 do
    S[Pos(' ', S)] := '_';
    result := s;
end;

function ConvertSpacesToZeros(S: string): string;
//var x: string;

begin
 //// S := '   123.5';
  { Convert spaces to zeros }
  while Pos(' ', S) > 0 do
    S[Pos(' ', S)] := '0';
end;

// goes through string deleting spaces

function ConvertSpacesToNothing(S: string): string;
var st: string;

begin
 /// S := '   123.5';
  { Convert spaces to zeros }
  while Pos(' ', S) > 0 do
                 begin
  st := st + getfirsttoken(s,' ',0);
  s :=   stripfirsttoken(s,' ',0);
                 end;
  result := st;
   //+ getlasttoken(s,' ');
  //  S[Pos(' ', S)] := '';
end;

//function



function GetNumberOfWords(LineofTxt: string): integer;
var
cnt: integer;
begin
 while Pos(' ', LineOfTxt) > 0 do
 begin
 cnt := cnt +1;
  LineOfTxt[Pos(' ', LineOfTxt)] := '0';
  end;
 GetNumberOfWords := cnt;

end;
 function GetLocationOfWord(LineofTxt: string; caretx: integer): integer;
var
cnt: integer;
begin
cnt := 0;
 while Pos(' ', LineOfTxt) > 0 do
 begin
  if pos(' ',lineoftxt) > caretx then
  break
  else
 cnt := cnt +1;

  LineOfTxt[Pos(' ', LineOfTxt)] := '0';

  end;
 GetLocationOfWord := cnt;

end;
// get word from string at word number x ie from middle of sting
// the cat sat on the mat given x = 3 the word 'sat' would be returned
// use getlocationofword to get which word number it is if you
// only have position ie from a sendmessage call to richedit .
function getWordFromStringAtX(s: string;x: integer): string;
var I: integer;
Begin
  for I := 1 to x do
  begin
  s := stripfirstword(s,' ');
  end;
 // if s<>''  then
 if getnumberofwords(s) <> 0 then
  getWordFromStringAtX :=  removefirstword(s)
  else
  getWordFromStringAtX :=  s;
 // else
 // getwordfromstringatx :=  getlasttoken(s,' ');
end;

function Address2Str(Addr: Pointer): string;
begin
  Result := Format('%p', [Addr]);
end;

function AddBackSlash(S: string): string;
var
 Temp: string;
begin
  Temp := S;
  if S[Length(Temp)] <> '\' then
    Temp := Temp + '\';
  AddBackSlash := Temp;
end;

{----------------------------------------------------
       Name: CleanString function
Declaration: CleanString(S: string): string;
       Unit: StrBox
       Code: S
       Date: 05/05/94
Description: Erase blanks from end and beginning of
             a string
-----------------------------------------------------}
function CleanString(S: string): string;
var
  Temp: string;
begin
  Temp := ''; 
  if Length(S) <> 0 then begin
    Temp := StripFrontChars(S, #32);
    Temp := StripBlanks(Temp);
  end;
  CleanString := Temp;
end;

{----------------------------------------------------
       Name: GetFirstWord function
Declaration: GetFirstWord(var S: string): string;
       Unit: StrBox
       Code: S
       Date: 05/02/94
Description: Get the first word from a string
-----------------------------------------------------}
function GetFirstWord(S : string) : string;
  Var
    i : Integer;
    S1: string;
begin
  i := 1;
  while (S[i] <> ' ') and (i < Length(S)) do begin
   setlength(s1,i);
     S1[i] := S[i];
     Inc(i);
  end;
 //// Dec(i);
 //// SetLength(S1, i);
  GetFirstWord := S1;
end;

function GetHexWord(w: Word): string;
const
  HexChars: array [0..$F] of Char =  '0123456789ABCDEF';
var
  Addr: string;
begin
  Addr[1] := hexChars[Hi(w) shr 4];
  Addr[2] := hexChars[Hi(w) and $F];
  Addr[3] := hexChars[Lo(w) shr 4];
  Addr[4] := hexChars[Lo(w) and $F];
  SetLength(Addr, 4);
  GetHexWord := addr;
end;

// maxInt gives you the last token stripped protection
// when the string is like this '10,' then it has errors
// see also stripfirsttoken

function GetFirstToken(S: string; Token: Char; maxInt: integer): string;
var
  Temp: string;
  Index: INteger;
begin


      if length(s) = 0 then
      exit;
      if s[1] = token then
      begin
      s[1] := ' ';
      s := trim(s);
       end;
       
      if length(s) > maxInt -1 then
        begin
  Index := Pos(Token, S);
  if Index < 1 then begin
    GetFirstToken := '';
    Exit;
  end;
  Dec(Index);
  SetLength(Temp, Index);
  Move(S[1], Temp[1], Index);
  GetFirstToken := Temp;
        end
        else
          begin
         //if ch = s[1] then
         if (maxInt = 2) and (length(s) <> 0)  then
         s := s[1];
         if maxInt =3 then
         s := s[1]+s[2];
          getfirsttoken := s;
         end;

end;

function GetLastWord(S: string): string;
var
temp: string;
begin
//
temp  := reversestr(s);
temp  := getfirstword(temp);
temp   :=   reversestr(temp);
// get rid of chariage return/line feed
result :=   shorten(temp,2);

end;

{ Get the last part of a string, from a token onward.
  Given "Sam.Txt", and "." as a token, this returns "Txt" }
function GetLastToken(S: string; Token: Char): string;
var
  Temp: string;
  Index: INteger;
begin
  S := ReverseStr(S);
  Index := Pos(Token, S);
  if Index < 1 then begin
    GetLastToken := '';
    Exit;
  end;
  Dec(Index);
  SetLength(Temp, Index);
  Move(S[1], Temp[1], Index);
  GetLastToken := ReverseStr(Temp);
end;

function GetLast3chars(S: string): string;
var
Temp: string;
begin
//
temp := reversestr(s);
temp := temp[3]+temp[2]+temp[1];
result := temp;
end;

{----------------------------------------------------
       Name: GetLogicalAddress function
Declaration: GetLogicalAddr(A: Pointer): Pointer;
       Unit: StrBox
       Code: S
       Date: 02/09/95
Description: Enter a physical address and this function
             will return a logical address.
-----------------------------------------------------}

{$ifdef OLDDELPHI}
function GetLogicalAddr(A: Pointer): Pointer;
var
  APtr: Pointer;
begin
  if A = nil then exit;
  if Ofs(A) = $FFFF then exit;
  asm
    mov ax, A.Word[0]
    mov dx, A.Word[2]
    mov es,dx
    mov dx,es:Word[0]
    mov APtr.Word[0], ax
    mov APtr.Word[2], dx
  end;
  GetLogicalAddr := APtr;
end;
{$endif}

function GetTimeString: string;
begin
  Result := TimeToStr(Time);
end;

function GetTimeFormat: string;
var
 h, m, s, hund : Word;
begin
   DecodeTime(Time, h, m, s, hund);
   GetTimeFormat:= Int2StrPad0(h, 2) + ':' +
           Int2StrPad0(m, 2) + ':' + Int2StrPad0(s, 2);
end;

{----------------------------------------------------
       Name: GetTodayName function
Declaration: GetTodayName(Pre, Ext: string): string;
       Unit: StrBox
       Code: S
       Date: 03/01/94
Description: Return a filename of type PRE0101.EXT,
             where PRE and EXT are user supplied strings,
             and 0101 is today's date.
-----------------------------------------------------}
function GetTodayName(Pre, Ext: string): string;
var
  y, m, d : Word;
  Year: string;
begin
  DecodeDate(Date,y,m,d);
  Year := Int2StrPad0(y, 4);
  Delete(Year, 1, 2);
  GetTodayName := Pre + Int2StrPad0(m, 2) + Int2StrPad0(d, 2) +
                    Year + '.' + Ext;
end;

{----------------------------------------------------
       Name: GetTodaysDate function
Declaration: GetTodaysDate: string;
       Unit: StrBox
       Code: S
       Date: 08/16/94
Description: Return a string of type MM/DD/YY.
-----------------------------------------------------}
function GetTodaysDate: string;
var
  y, m, d: Word;
  Year: string;
begin
  DecodeDate(Date, y,m,d);
  Year := Int2StrPad0(y, 4);
  Delete(Year, 1, 2);
  GetTodaysDate := Int2StrPad0(m, 2) + '/' + Int2StrPad0(d, 2) + '/' + Year;
end;

function isalpha(c : char ) : boolean;
begin
 case c of
  'a'..'z' ,'A'..'Z' : //,#10,#13 :
   result:=true;

  else
   result:=false;

 end;
end;

function IsNumber(Ch: Char): Boolean;
begin
  IsNumber := ((Ch >= '0') and (Ch <= '9'));
end;

{----------------------------------------------------
       Name: LeftSet function
Declaration: LeftSet(src: string; Width: Integer;
                     var Trunc: Boolean): string;
       Unit: StrBox
       Code: S
       Date: 03/01/94
Description: Pad a string on the left
-----------------------------------------------------}
function LeftSet(src: string; Width: Integer; var Trunc: Boolean): string;
var
  I : Integer;
  Temp: string[80];
begin
  Trunc := False;
  Temp := src;
  if(Length(Temp) > Width) and (Width > 0) then begin
    Temp[0] := CHR(Width);
    Trunc := True;
  end else
    for i := Length(Temp) to width do
      Temp := Temp + ' ';
  LeftSet := Temp;
end;

{----------------------------------------------------
       Name: RemoveFirstWord function
Declaration: RemoveFirstWord(var S : string) : string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Strip the first word from a sentence,
             return word and a shortened sentence.
             Return an empty string if there is no
             first word.
-----------------------------------------------------}
function RemoveFirstWord(var S : string) : string;  overload
var
  i, Size: Integer;
  S1: string;
begin
  i := Pos(#32, S);
  if i = 0 then begin
    RemoveFirstWord := '';
    Exit;
  end;
  SetLength(S1, i);
  Move(S[1], S1[1], i);
  SetLength(S1, i-1);
  Size := (Length(S) - i);
  Move(S[i + 1], S[1], Size);
  SetLength(S, Size);
  RemoveFirstWord := S1;
end;
function RemoveFirstWord(var S : widestring) : widestring; overload
var
  i, Size: Integer;
  S1: string;
begin
  i := Pos(#32, S);
  if i = 0 then begin
    RemoveFirstWord := '';
    Exit;
  end;
  SetLength(S1, i);
  Move(S[1], S1[1], i);
  SetLength(S1, i-1);
  Size := (Length(S) - i);
  Move(S[i + 1], S[1], Size);
  SetLength(S, Size);
  RemoveFirstWord := S1;
end;

{----------------------------------------------------
       Name: ReplaceString
Declaration: ReplaceString(NewStr, ReplaceStr, Data: string): string;
       Unit: StrBox
       Code: S
       Date: 06/06/95
Description: Given a long string, replace one substring with another.
             Take the string: "Football Delight"
             The job is to replace the word Delight with Night:
             S := ReplaceString(Night, Delight, 'Football Delight');
             where S ends up equaling "Football Night'; 
-----------------------------------------------------}

function ReplaceStringOld(NewStr, ReplaceStr, Data: string): string;
var
  OffSet: Integer;
  resultstr: string;
begin
  OffSet := Pos(ReplaceStr, Data);
  Delete(Data, OffSet, Length(ReplaceStr));
  Insert(NewStr, Data, OffSet);
  Result := Data;
end;
//
function ReplaceString(NewStr, ReplaceStr, Data: string): string;
var
  OffSet: Integer;
  resultstr: string;
begin
 { OffSet := Pos(ReplaceStr, Data);
  Delete(Data, OffSet, Length(ReplaceStr));
  Insert(NewStr, Data, OffSet);
  Result := Data;   }
resultstr :=  ReplaceString2(NewStr, ReplaceStr, Data);
 resultstr :=  ReplaceString2(NewStr+',', ReplaceStr, Data);

 resultstr :=  ReplaceString2(StripFromFront(NewStr,1), ReplaceStr, Data);
 result := resultstr
 end;

function ReplaceString2(NewStr, ReplaceStr, Data: string): string;
var
  OffSet: Integer;
begin
  OffSet := Pos(ReplaceStr, Data);
  Delete(Data, OffSet, Length(ReplaceStr));
  Insert(NewStr, Data, OffSet);
  Result := Data;
end;

function ReplaceChars(S: string; OldCh, NewCh: Char): string;
var
  Len: Integer;
  i: Integer;
begin
  Len := Length(S);
  for i := 1 to Len do
    if S[i] = OldCh then
      S[i] := NewCh;
  Result := S;
end;

function ReverseStr(S: string): string;
var
  Len: Integer;
  Temp: string;
  i,j: Integer;
begin
  Len := Length(S);
  SetLength(Temp, Len);
  j := Len;
  for i := 1 to Len do begin
    Temp[i] := S[j];
    dec(j);
  end;
  ReverseStr := Temp;
end;

function RightCharSet(Src: string; Width: Integer;
                      Ch: Char; var Trunc: Boolean): string;
var
  I : Integer;
  Temp: string[80];
begin
  Trunc := False;
  Temp := Src;
  if(Length(Temp) > Width) and (Width > 0) then begin
    Temp[0] := CHR(Width);
    Trunc := True;
  end else
    for i := Length(Temp) to (width - 1) do
      Temp := Ch + Temp ;
  RightCharSet := Temp;
end;

function Shorten(S: string; Cut: Integer): string;
begin
  SetLength(S, Length(S) - Cut);
  Shorten := S;
end;

procedure SplitDirName(Path : PathStr; var Dir: DirStr; var WName: Str12);
begin
  Dir := ExtractFilePath(Path);
  WName := ExtractFileName(Path);
end;
{
procedure SplitDirName(Path : PathStr; var Dir: DirStr; var WName: Str12);
begin
  FSplit(Path, Dir, Name, Ext);
  WName := ExtractFileName(Path);
end;
}

{----------------------------------------------------
       Name: StripBlanks function
Declaration: function StripBlanks(var S: string): string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Strip any stray spaces from the end of
             a string
-----------------------------------------------------}
function StripBlanks(S: string): string;
var
  i: Integer;
begin
  i := Length(S);
  while (Length(S) <= i) and (Length(S) > 0) and (S[i] = ' ') do begin
    Delete(S,i,1);
    Dec(i);
  end;
  StripBlanks := S;
end;

function StripEndChars(S: string; Ch: Char): string;
var
  i: Integer;
begin
  i := Length(S);
  while (length(S) > 0) and (S[i] = Ch) do begin
    Delete(S,i,1);
    Dec(i);
  end;
  StripEndChars := S;
end;


function StripFirstToken(S: string; Ch: Char; smalllimit: integer): string;
var
  i, Size: Integer;
begin
if length(s) > smalllimit then
        begin
        //form1.panel60.caption := inttostr(length(s));
  i := Pos(Ch, S);
  if i = 0 then begin
    StripFirstToken := S;
    Exit;
  end;
  Size := (Length(S) - i);
  Move(S[i + 1], S[1], Size);
  SetLength(S, Size);

         end
         else
         begin
         //if ch = s[1] then
         if smalllimit = 2 then
         s := ',';
         if smalllimit =3 then
         s := ',';
         end;
  StripFirstToken := S;
end;

{----------------------------------------------------
       Name: StripFirstWord function
Declaration: StripFirstWord(S : string) : string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Strip the first word from a sentence,
             return the shortened sentence this requires the
             white space option. Else you can search for a string
             then return original
             string if there is no first word. x can be white space
             ie one blank character
             or a word.
-----------------------------------------------------}
function StripFirstWord(S : string;x:string) : string;
var
  i, Size: Integer;
begin
 // i := Pos(#32, S); for white space detection option comment out
 // next line and replace with this (also change parameter template
 // to char :)
 i := Pos(x,s);
  if i = 0 then begin
    StripFirstWord := S;
    Exit;
  end;
  Size := (Length(S) - i);
  Move(S[i + 1], S[1], Size);
  SetLength(S, Size);
  StripFirstWord := S;
end;
function StripHTMLTag(S : string;x:string) : string;
var
  i, Size: Integer;
begin
 // i := Pos(#32, S); for white space detection option comment out
 // next line and replace with this (also change parameter template
 // to char :)
 i := Pos(x,s);
  if i = 0 then begin
    StripHTMLTag := S;
    Exit;
  end;
  Size := (Length(S) - i);
  Move(S[i +1], S[1], Size);
  SetLength(S, Size);
  StripHTMLTag := S;
end;
{----------------------------------------------------
       Name: StripFrontChars function
Declaration: StripFrontChars(S: string; Ch: Char) : string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Strips any occurances of charact Ch that
             might precede a string.
-----------------------------------------------------}
function StripFrontChars(S: string; Ch: Char): string;
begin
  while (Length(S) > 0) and (S[1] = Ch) do
    S := Copy(S,2,Length(S) - 1);
  StripFrontChars := S;
end;

// try to use this ... much faster than stripfromfront
// doesn't do 2 reverse str functions
function StripFromBack(S: string; Len: Integer): string;
begin
   S := Shorten(S, Len);
   StripFromBack := S;
   end;

function StripFromFront(S: string; Len: Integer): string;
begin
  S := ReverseStr(S);
  S := Shorten(S, Len);
  S := ReverseStr(S);
  StripFromFront := S;
end;

{----------------------------------------------------
       Name: StripLastToken function
Declaration: function RemoveLastToken(var S: string): string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Given a string like "c:\sam\file.txt"
             This returns: "c:\sam"
             But not specific to files any token will do
-----------------------------------------------------}
function StripLastToken(S: string; Token: Char): string;
var
  Temp: string;
  Index: INteger;
begin
  SetLength(Temp, Length(S));
  S := ReverseStr(S);
  if pos(Token,s) = length(s)  then
        begin
        setlength(s, length(s)-1);
        result := reverseStr(s);
        exit;
        end;
  Index := Pos(Token, S);
  Inc(Index);
  Move(S[Index], Temp[1], Length(S) - (Index - 1));
  SetLength(Temp, Length(S) - (Index - 1));
  StripLastToken := ReverseStr(Temp);
end;

function Q_StrHashKey(const S: string): LongWord;
asm
TEST EAX,EAX
JE @@qt
LEA EDX,[EAX-1]
MOV ECX,[EAX-4]
XOR EAX,EAX
TEST ECX,ECX
JE @@qt
PUSH ESI
PUSH EBX
@@lp: MOV ESI,EAX
SHL EAX,5
MOVZX EBX,BYTE PTR [EDX+ECX]
ADD EAX,ESI
ADD EAX,EBX
DEC ECX
JNE @@lp
POP EBX
POP ESI
@@qt:
end;
 function Q_StrHashPassEnc(const S: string): String;
 var
 temp,temp2,s1: string;
 x:   integer;
 begin
 //
 s1    :=  rot13(s); // rotateby(s);
 temp2 :=  inttostr(Q_StrHashKey(s));
 temp2 :=  temp2+rot13(temp2);
 //form1.lblHashSeed.caption := rotateby(temp2)+temp2+rotateby(datetostr(now));
 while length(temp2) < length(s1) do
  temp2 := temp2 + temp2;

  for x := 1 to length(s1) do
         begin
         temp := temp + s1[x]+temp2[x];
         end;
         result := temp;
 end;

 function Q_StrHashPassDec(const S: string): String;
 var
 temp,temp2,s1: string;
 x:   integer;
 begin
 //
{ s1    :=  rotateby(s);
 temp2 :=  inttostr(Q_StrHashKey(s));
 temp2 :=  temp2+rot13(temp2);
 form1.lblHashSeed.caption := temp2; }
// while length(temp2) < length(s1) do
//  temp2 := temp2 + temp2;

  for x := 1 to length(s) do
         begin
         if odd(x) then
         temp := temp + s[x];//+temp2[x];
         end;
         result := rot13(temp);
 end;

 function rot13(sInput: string): string;
 const
  rot13a: array ['A'..'Z'] of Char = 'NOPQRSTUVWXYZABCDEFGHIJKLM';
  rot13b: array ['a'..'z'] of Char = 'nopqrstuvwxyzabcdefghijklm';
 rot13c: array ['0'..'9'] of Char = '9876543210';
 //rot13c: array ['0'..'9'] of Char ='(*&^%$#@!)';
   //  rot13d: array ['0'..'9'] of Char ='(*&^%$#@!)';
   //  rot13d: array ['*'..'&'] of Char ='9876543210';
var
  t: String;
  i,n: Integer;
begin

  t := sInput;
  for i := 1 to Length(t) do
    if t[i] in ['A'..'Z'] then
      t[i] := rot13a[t[i]]
    else if t[i] in ['a'..'z'] then
      t[i] := rot13b[t[i]];
  //    n:= length(rot13c);
   //   showmessage(inttostr(n));

  for i := 1 to Length(t) do
      if t[i] in ['0'..'9'] then
      t[i] := rot13c[t[i]]
      else if t[i] = ' ' then
      t[i] := ' ';
      ///t[i] := char(randomrange(100,125));

  result := t;
end;


function RotateBy(AStr: String; const ARotate: Integer = 47): String;

  function RotateChar(AChr: Char; ARotate: Integer): Char;
  var
    iStart, iRotate: Integer;
  begin
    iStart := 0;
    case ARotate of
       5: if AChr in ['0'..'9'] then
          begin
            iStart := 48;                                   // '0'
            iRotate := 5;
          end;
      13: if AChr in ['A'..'Z'] then
          begin
            iStart := 65;                                   // 'A'
            iRotate := 13;
          end
          else if Achr in ['a'..'z'] then
          begin
            iStart := 97;                                   // 'a'
            iRotate := 13;
          end;
      18: if AChr in ['0'..'9'] then
          begin
            iStart := 48;                                   // '0'
            iRotate := 5;
          end
          else if AChr in ['A'..'Z'] then
          begin
            iStart := 65;                                   // 'A'
            iRotate := 13;
          end
          else if AChr in ['a'..'z'] then
          begin
            iStart := 97;                                   // 'a'
            iRotate := 13;
          end;
      47: if AChr in ['!'..'~'] then
          begin
            iStart := 33;                                   // '!'
            iRotate := 47;
          end
    end;
   
    if iStart <> 0 then
      Result := Chr(iStart + ((Ord(AChr) - iStart + iRotate) mod (iRotate * 2)))
    else // its a space so lets add some chaos :)
     // if odd(istart) then
     // Result := '\A5' //(ie pound character);
    //  else
    //if yenpound = false then
    //  Result := '\A3'
    //  else
   // if nopound = false then
      Result := char(randomrange(160,180));//'\A5' ;
    //  or (t[i] =  '\80')
   //   else
   //  result :=  '\80';
  ////  nopound  := not(nopound);
   // yenpound := odd(randomrange(100));
  //  yenpound := not(yenpound);
  end;

var
  I: Integer;
begin
  Result := '';
  for I := 1 to Length(AStr) do
    Result := Result + RotateChar(AStr[I], ARotate);
end;


//showmessage('here');


end.


