#!/bin/bash 
btop --low-color
