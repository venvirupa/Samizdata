unit STRBOX3;
 {$mode ObjFPC}{$H+}
//.$DEFINE OLDDELPHI
interface

uses
  MathBox, classes, SysUtils, dateutils,dialogs,
  StrUtils, types, Unix, BaseUnix,hashfunctions,process;
  // Math = myMath;
const
  CR = #13#10;

type
  Str12 = string[12];
  DirStr = string[67];
  PathStr = string[79];
  NameStr = string[8];
  ExtStr = string[4];
  TStringArray = array of string;


function Address2Str(Addr : Pointer) : string;
function AddBackSlash(S: string): string;
function AddDecimalPointToStrAt(S: string;P: integer): string;
function CleanString(S: string): string;
function ConvertSpacesToZeros(S: string): string;
function ConvertSpacesToUnderlines(S: string): string;
function ConvertSpacesToNothing(S: string): string;
function ExecuteRsyncCommand(ExecString: string; SL: tstringlist): tstringlist;
function ExecuteCmdDetach(ExecString: string; SL: tstringlist): tstringlist;
function ExecuteExists(ExecString: string): boolean;
function ExtendedRot13(const Source: string): string;
function FindWindowLinux(windowStr: string): boolean;
function FindOSname(windowStr: string): boolean;
function FixIncDay(DateStr: string): string;
function GetNumberOfWords(LineofTxt: string): integer;
//get word from positon x
function GetWordFromStringAtX(s: string;x: integer): string;
function GetLocationOfWord(LineofTxt: string; caretx: integer): integer;
function GetPkExec(p: string): integer;
function GetFirstWord(S: string): string;
function GetFirstToken(S: string; Token: Char): string;
function GetHexWord(w: Word): string;
function GetLastToken(S: string; Token: Char): string;
{$ifdef OLDDELPHI}
function GetLogicalAddr(A: Pointer): Pointer;
{$endif}
function GetTodayName(Pre, Ext: string): string;
function GetTodaysDate(incNumber: integer;separatorStr: string): string;
//function GetDateString: string;
function GetTimeString(inc: integer): string;
function GetTimeFormat: string;
function IsNormalUser: Boolean;
function IsNumber(Ch: Char): Boolean;
function LeftSet(src: string; Width:Integer; var Trunc: Boolean): string;
function ReplaceChars(S: string; OldCh, NewCh: Char): string;
function RightCharSet(Src: string; Width: Integer;
                      Ch: Char; var Trunc: Boolean): string;
function RemoveFirstWord(var S : string) : string;    overload ;
function RemoveFirstWord(var S : widestring) : widestring;  overload  ;
function RemoveFirstWordAI(const S: string): string;
function ReplaceString(NewStr, ReplaceStr, Data: string): string;
function ReverseStr(S: string): string;
function Rot13(S: string): string;
procedure RunsLsRoot;
function ObfuStr(S: string): string;
function SafeSortStringList(SL: tstringlist; HeaderStr: string): TStringlist;
function Shorten(S: string; Cut: Integer): string;
function ShortenFilePath(S: string; os: integer): string;
function StripFirstNumberChars(S: string;number: integer): string;
procedure SplitDirName(Path : PathStr; var Dir: DirStr; var WName: Str12);
function StripBlanks(S: string): string;
function StripEndChars(S: string; Ch: Char): string;
function StripFirstWord(S : string; x: string) : string;
function StripHTMLTag(S : string; x: string) : string;
function StripFirstToken(S: string; Ch: Char): string;
function StripFrontChars(S: string; Ch: Char): string;
function StripFromFront(S: string; Len: Integer): string;
function StripLastToken(S: string; Token: Char): string;
function StripLastTokenList(SL: tstringList; Token: Char): tstringlist;
function StringToArrayOfWords(S: string): TStringDynArray;
function StringBubbleSort( names: tstringarray): tstringarray;
function GetURLFromString(S: string): string;
function RandomString(strLength: integer): string;
{$ifdef OldDelphi}
procedure SetLength(var S: string; i: Integer);
{$endif}

implementation


{$ifdef OldDelphi}
procedure SetLength(var S: string; i: Integer);
begin
  S[0] := Chr(i);
end;
{$endif}
{function Q_StrHashKey(const S: string): LongWord;
begin
  {$ASMMODE intel}


asm
TEST EAX,EAX
JE @@qt
LEA EDX,[EAX-1]
MOV ECX,[EAX-4]
XOR EAX,EAX
TEST ECX,ECX
JE @@qt
PUSH ESI
PUSH EBX
@@lp: MOV ESI,EAX
SHL EAX,5
MOVZX EBX,BYTE PTR [EDX+ECX]
ADD EAX,ESI
ADD EAX,EBX
DEC ECX
JNE @@lp
POP EBX
POP ESI
@@qt:
end;
end;

 function Q_StrHashPassEnc(const S: string): String;
 var
 temp,temp2,s1: string;
 x:   integer;
 begin
 //
 s1    :=  rot13(s); // rotateby(s);
 temp2 :=  inttostr(Q_StrHashKey(s));
 temp2 :=  temp2+rot13(temp2);
 //form1.lblHashSeed.caption := rotateby(temp2)+temp2+rotateby(datetostr(now));
 while length(temp2) < length(s1) do
  temp2 := temp2 + temp2;

  for x := 1 to length(s1) do
         begin
         temp := temp + s1[x]+temp2[x];
         end;
         result := temp;
 end;

 function Q_StrHashPassDec(const S: string): String;
 var
 temp,temp2,s1: string;
 x:   integer;
 begin
 //
{ s1    :=  rotateby(s);
 temp2 :=  inttostr(Q_StrHashKey(s));
 temp2 :=  temp2+rot13(temp2);
 form1.lblHashSeed.caption := temp2; }
// while length(temp2) < length(s1) do
//  temp2 := temp2 + temp2;

  for x := 1 to length(s) do
         begin
         if odd(x) then
         temp := temp + s[x];//+temp2[x];
         end;
         result := rot13(temp);
 end;      }
 // given a list of strings like a list of people, then
 // sort them alphabetically ( or alphanumerically even if string type )

 //FixIncDay ... the IncDay function in dateutils returns a
 // formating like this 23-04-2026 but we want it formatted like this
 // 23/04/26 without the 20 infront of the year
 function ExtendedRot13(const Source: string): string;
var
  Charset: string;
  i, j, Len: Integer;
  ResultStr: string;
begin
  // Define the character set to be rotated (e.g., letters + digits + symbols)
  Charset := 'abcdefghijklmnopqrstuvwxyz0123456789!@~$%-:#+=[]()<>?/&^*\,.';
  Len := Length(Charset);

  // Ensure the charset length is even for a clean involution (optional but recommended)
  // For strict ROT13 behavior on an odd-length set, you must define a specific shift key.

  ResultStr := '';
  for i := 1 to Length(Source) do
  begin
    // Find the position of the current character in the charset
    j := Pos(UpperCase(Source[i]), UpperCase(Charset));

    if j > 0 then
    begin
      // Calculate the new position
      // For standard ROT13 on this set, shift by Floor(Len / 2)
      // If Len is odd, this is not a perfect involution without a custom key.
      if Len mod 2 = 0 then
        j := ((j - 1 + (Len div 2)) mod Len) + 1
      else
        // Custom shift for odd-length sets (e.g., shift by 13 if Len >= 13)
        j := ((j - 1 + 13) mod Len) + 1;

      // Append the rotated character
      ResultStr := ResultStr + Charset[j];
    end
    else
    begin
      // Leave characters not in the charset unchanged
      ResultStr := ResultStr + Source[i];
    end;
  end;

  ExtendedRot13 := ResultStr;
end;
 function FixIncDay(DateStr: string): string;
 var
   S: string;

 begin
   //
 s :=   replacechars(DateStr,'-','/');
 s :=  getlasttoken(s,'/')  ;
    if length(s) > 2 then
    s := Copy(s, Length(s) - 1, 2);
    result := striplasttoken(dateStr,'/')+'/'+s;
 end;

function StringBubbleSort( names: tstringarray): tstringarray;



var
  ///Names: array of string;
  i, j: Integer;
  Temp: string;
  Swapped: Boolean;

begin
  // Initialize the array with some names
 { SetLength(Names, 5);
  Names[0] := 'Charlie';
  Names[1] := 'Alice';
  Names[2] := 'Bob';
  Names[3] := 'David';
  Names[4] := 'Eve';  }

  // Bubble Sort Algorithm
  i := 0;
  repeat
    Swapped := False;
    // Loop through the array, reducing the range each pass
    for j := 0 to High(Names) - 1 - i do
    begin
      // Compare adjacent strings
      if Names[j] > Names[j + 1] then
      begin
        // Swap if the current string is "greater" (comes later alphabetically)
        Temp := Names[j];
        Names[j] := Names[j + 1];
        Names[j + 1] := Temp;
        Swapped := True;
      end;
    end;
    Inc(i);
  until (not Swapped) or (i >= High(Names));

  // Output the sorted array to the calling code
  result := names;
//  for i := 0 to High(Names) do
  //  WriteLn(Names[i]);
end;

function RandomString(strLength: integer): string;
var
  charSet: string;
  charSetLength, i: integer;
  resultStr: string;
begin
  // Define the character set (digits, lowercase, uppercase)
  charSet := '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  charSetLength := Length(charSet);
  resultStr := '';

  // Initialize the random seed
  Randomize;

  // Build the string by picking random indices
  for i := 1 to strLength do
  begin
  //randomize;

    resultStr := resultStr + charSet[Random(charsetlength) + 1];//+charset[random(19-i)+1];
   //  randomize;
  end;

  result := resultStr;
end;

// a safe sort for CSV style data so the header isn't trashed
function SafeSortStringList(SL: tstringlist; HeaderStr: string): TStringlist;

begin
  SL := tstringlist.Create;
//  SL.LoadFromFile(CSVDataset1.FileName);
  sl.Sort;        // we now have to fix the column headers as they
                  // get trashed by the sort ( uses alphanumeric ordering so
                  // headers are placed at end of list )
                  // and need to be inserted again
                  // at 0 for CSV formatted database to stay correct
  //csvdataset1.Close;

     sl.insert(0,HeaderStr);
     sl.delete(sl.Count -1 );
 //    SL.SaveToFile(CSVDataset1.FileName);

   //  csvdataset1.Open;
  //   csvdataset1.refresh;
  //   dbgrid1.Columns[0].visible := false;
  result := sl;

end;
function StringToArrayOfWords(S: string): TStringDynArray;
var
  SourceString: string;
  WordArray: TStringDynArray;
  i: Integer;
begin
  SourceString := 'Hello world from Pascal';

  // Split by space character
  WordArray := SplitString(SourceString, ' ');

 // for i := 0 to High(WordArray) do
 //  Writeln(WordArray[i]);
  result := wordArray;
end;


function GetURLFromString(S: string): string;
begin
  //
end;
function ConvertSpacesToUnderlines(S: string): string;
//var x: string;

begin
  S := '   123.5';
  { Convert spaces to _ }
  while Pos(' ', S) > 0 do
    S[Pos(' ', S)] := '_';
end;

function ConvertSpacesToZeros(S: string): string;
//var x: string;

begin
 // S := '   123.5'; // just init with some value
  { Convert spaces to zeros }
  while Pos(' ', S) > 0 do
    S[Pos(' ', S)] := '0';
end;
function AddDecimalPointToStrAt(S: string;P: integer): string;
//var x: string;

begin
 // S := '   123.5'; // just init with some value
  { Convert spaces to zeros }
 // while Pos(' ', S) > 0 do
  S[P] := '.';
   // S[Pos(' ', S)] := '0';
   result := S;
end;

function ConvertSpacesToNothing(S: string): string;
//var x: string;

begin
  S := '   123.5';
  { Convert spaces to zeros }
 /// while Pos(' ', S) > 0 do
 ///   S[Pos(' ', S)] := '';
end;


  // get number of words in a string

function GetNumberOfWords(LineofTxt: string): integer;
var
cnt: integer;
begin
cnt := 0;
 while Pos(' ', LineOfTxt) > 0 do
 begin
 cnt := cnt +1;
  LineOfTxt[Pos(' ', LineOfTxt)] := '0';
  end;
 GetNumberOfWords := cnt;

end;

// gets location of a word in a string

 function GetLocationOfWord(LineofTxt: string; caretx: integer): integer;
var
cnt: integer;
begin
cnt := 0;
 while Pos(' ', LineOfTxt) > 0 do
 begin
  if pos(' ',lineoftxt) > caretx then
  break
  else
 cnt := cnt +1;

  LineOfTxt[Pos(' ', LineOfTxt)] := '0';

  end;
 GetLocationOfWord := cnt;

end;

// get word from string at word number x ie from middle of sting
// the cat sat on the mat given x = 3 the word 'sat' would be returned
// use getlocationofword to get which word number it is if you
// only have position ie from a sendmessage call to richedit .

function getWordFromStringAtX(s: string;x: integer): string;
var I: integer;
Begin
  for I := 1 to x do
  begin
  s := stripfirstword(s,' ');
  end;
 // if s<>''  then
 if getnumberofwords(s) <> 0 then
  getWordFromStringAtX :=  removefirstword(s)
  else
  getWordFromStringAtX :=  s;
 // else
 // getwordfromstringatx :=  getlasttoken(s,' ');
end;
function IsNormalUser: Boolean;
var
  Proc: TProcess;
  Output: TStringList;
begin
  Proc := TProcess.Create(nil);
  Output := TStringList.Create;
  try
    Proc.Options := Proc.Options + [poUsePipes];
    Proc.Executable := 'id';
    Proc.Parameters.Add('-u');
    Proc.Execute;
    Output.LoadFromStream(Proc.Output);
    Result := (Trim(Output.Text) <> '0');
  finally
    Output.Free;
    Proc.Free;
  end;
end;
function Address2Str(Addr: Pointer): string;
begin
  Result := Format('%p', [Addr]);
end;

function AddBackSlash(S: string): string;
var
 Temp: string;
begin
  Temp := S;
  if S[Length(Temp)] <> '\' then
    Temp := Temp + '\';
  AddBackSlash := Temp;
end;

{----------------------------------------------------
       Name: CleanString function
Declaration: CleanString(S: string): string;
       Unit: StrBox
       Code: S
       Date: 05/05/94
Description: Erase blanks from end and beginning of
             a string
-----------------------------------------------------}
function CleanString(S: string): string;
var
  Temp: string;
begin
  Temp := ''; 
  if Length(S) <> 0 then begin
    Temp := StripFrontChars(S, #32);
    Temp := StripBlanks(Temp);
  end;
  CleanString := Temp;
end;
function  GetPkExec(p: string): integer;
 var
   Proc: TProcess;
   ExitCode: Integer;
 begin
   Proc := TProcess.Create(nil);
   try
     Proc.Executable := 'lazpolkit-pkexec';
     Proc.Parameters.Add('project1');
     Proc.Options := Proc.Options + [poWaitOnExit, poStderrToOutPut];
     Proc.Execute;
     ExitCode := Proc.ExitCode;
   finally
     Proc.Free;
   end;

   if ExitCode = 0 then
     ShowMessage('Privileges granted.')
   else if ExitCode = 126 then
     ShowMessage('Authentication cancelled.')
   else
     ShowMessage('Authorization failed.');
   result := exitcode;
 end;

// find out if an executable file actually exists
// on the system using command -v to ask the OS
// command will not reply if the file does not
// exist, if it does will return the path

function ExecuteExists(ExecString: string): boolean;
      var
        slx,line: string;
        sl2: tstringlist;
        f: text;
begin

     sl2 := tstringlist.Create;
  //boolResult := false;
  slx := 'command -v '+execstring;
  // Execute wmctrl -l -p to list windows with PIDs
  POpen(f, slx, 'r');
  //writeln(f,'test');
  while not EOF(f) do
  begin
    ReadLn(f, line);
    //if pos(windowStr,line) <> 0 then
    //boolResult := true;
    sl2.Add(line);
    // Parse 'line' to extract window ID, PID, or title as needed
    // Example: Split by spaces to identify specific windows
  end;
  Close(f);
   { if fileexists(execstring) then
   if sl2.count = 0 then
 ExecuteExists('./'+execstring);  }

   if sl2.count = 0 then
   result := false
   else
   result := true;
 //  sl2.Destroy;
end;

function ExecuteCmdDetach(ExecString: string; SL: tstringlist): tstringlist;
var
  AProcess: TProcess;
  sl3:   tstringlist;
begin
  if not executeExists(getfirstword(execstring)) then
  begin
    if ExecString <> 'build' then
    showmessage(getfirstword(ExecString)+' can not be found.');
  exit;
  end;
 { sl3 := tstringlist.create;
sl3 := executeRsyncCommand('command -v '+execstring,sl3);
 if sl3.Count = 0 then
 begin
   showmessage('Program not found');
   exit;
 end;    }
  AProcess := TProcess.Create(nil);
  try
    AProcess.CommandLine := ExecString;
    // poNoConsole is optional; poWaitOnExit is omitted to detach
    AProcess.Options := AProcess.Options + [poNoConsole];
    AProcess.Execute;
    // Do not free AProcess immediately if you need to track it later,
    // but do not wait for it.
  finally
    // AProcess.Free; // Only free if you don't need the object anymore
  end;

  end;
// execute rsync -rv ( for example or any other program ) or other commands
// and reture text results    hangs program execution until return
 function ExecuteRsyncCommand(ExecString: string; SL: tstringlist): tstringlist;
var
  f: Text;
  line: string;
  boolResult : boolean;
  SL2,sl3: tstringlist;
begin
  if not executeExists(execstring) then
  begin
    showmessage('File does not exit, or you do not have rights.');
  exit;
  end;
{ sl3 := tstringlist.create;

sl3 := executeRsyncCommand('command -v '+execstring,sl3);
 if sl3.Count = 0 then
 begin
   showmessage('Program not found');
   exit;
 end;     }
 sl2 := tstringlist.Create;
  boolResult := false;
  // Execute wmctrl -l -p to list windows with PIDs
  POpen(f, execstring, 'r');
  //writeln(f,'test');
  while not EOF(f) do
  begin
    ReadLn(f, line);
    //if pos(windowStr,line) <> 0 then
    //boolResult := true;
    sl2.Add(line);
    // Parse 'line' to extract window ID, PID, or title as needed
    // Example: Split by spaces to identify specific windows
  end;
  Close(f);
  ExecuteRsyncCommand := SL2;
end;
{----------------------------------------------------
       Name: GetFirstWord function
Declaration: GetFirstWord(var S: string): string;
       Unit: StrBox
       Code: S
       Date: 05/02/94
Description: Get the first word from a string
-----------------------------------------------------}
function GetFirstWord(S : string) : string;
var
  MyString: string;
  FirstWord: string;
begin
 // MyString := 'Hello World from Pascal';
  // Extract the 1st word using space as the delimiter
  s := ExtractWord(1, s, [' ']);
  result := s;
  //Writeln(FirstWord); // Output: Hello
end  ;
{  Var
    i : Integer;
    S1: string;
begin
  i := 1;
  s1 := 'abc';
  while (S[i] <> ' ') and (i < Length(S)) do begin
     S1[i] := S[i];
     Inc(i);
  end;
  Dec(i);
  SetLength(S1, i);
  GetFirstWord := S1;
end;     }


function GetHexWord(w: Word): string;
const
  HexChars: array [0..$F] of Char =  '0123456789ABCDEF';
var
  Addr: string;
begin
  Addr[1] := hexChars[Hi(w) shr 4];
  Addr[2] := hexChars[Hi(w) and $F];
  Addr[3] := hexChars[Lo(w) shr 4];
  Addr[4] := hexChars[Lo(w) and $F];
  SetLength(Addr, 4);
  GetHexWord := addr;
end;

function GetFirstToken(S: string; Token: Char): string;
var
  Temp: string;
  Index: INteger;
begin
  Index := Pos(Token, S);
  if Index < 1 then begin
    GetFirstToken := '';
    Exit;
  end;
  Dec(Index);
  SetLength(Temp, Index); 
  Move(S[1], Temp[1], Index);
  GetFirstToken := Temp;
end;

{ Get the last part of a string, from a token onward.
  Given "Sam.Txt", and "." as a token, this returns "Txt" }
  
function GetLastToken(S: string; Token: Char): string;
var
  Temp: string;
  Index: INteger;
begin
  S := ReverseStr(S);
  Index := Pos(Token, S);
  if Index < 1 then begin
    GetLastToken := '';
    Exit;
  end;
  Dec(Index);
  SetLength(Temp, Index);
  Move(S[1], Temp[1], Index);
  GetLastToken := ReverseStr(Temp);
end;

{----------------------------------------------------
       Name: GetLogicalAddress function
Declaration: GetLogicalAddr(A: Pointer): Pointer;
       Unit: StrBox
       Code: S
       Date: 02/09/95
Description: Enter a physical address and this function
             will return a logical address.
-----------------------------------------------------}

{$ifdef OLDDELPHI}
function GetLogicalAddr(A: Pointer): Pointer;
var
  APtr: Pointer;
begin
  if A = nil then exit;
  if Ofs(A) = $FFFF then exit;
  asm
    mov ax, A.Word[0]
    mov dx, A.Word[2]
    mov es,dx
    mov dx,es:Word[0]
    mov APtr.Word[0], ax
    mov APtr.Word[2], dx
  end;
  GetLogicalAddr := APtr;
end;
{$endif}
        // get time in string format with increment in minutes
        // so call in a loop adding 5 mins each time or 0 for no inc
function GetTimeString(inc: integer): string;
var
  timeStr: string;
  MyTime: TDateTime;
begin
     MyTime := Now;
     if inc <> 0 then
 MyTime :=  IncMinute(MyTime, inc);
  Result := TimeToStr(MyTime);
end;
function GetDateString: string;
var
    dateStr: string;
  MyTime: TDateTime;
begin
  //

end;

function GetTimeFormat: string;
var
 h, m, s, hund : Word;
begin
   DecodeTime(Time, h, m, s, hund);
   GetTimeFormat:= Int2StrPad0(h, 2) + ':' +
           Int2StrPad0(m, 2) + ':' + Int2StrPad0(s, 2);
end;

{----------------------------------------------------
       Name: GetTodayName function
Declaration: GetTodayName(Pre, Ext: string): string;
       Unit: StrBox
       Code: S
       Date: 03/01/94
Description: Return a filename of type PRE0101.EXT,
             where PRE and EXT are user supplied strings,
             and 0101 is today's date.
-----------------------------------------------------}
function GetTodayName(Pre, Ext: string): string;
var
  y, m, d : Word;
  Year: string;
begin
  DecodeDate(Date,y,m,d);
  Year := Int2StrPad0(y, 4);
  Delete(Year, 1, 2);
  GetTodayName := Pre + Int2StrPad0(m, 2) + Int2StrPad0(d, 2) +
                    Year + '.' + Ext;
end;
 function FindOSname(windowStr: string): boolean;
   var
  f: Text;
  line: string;
  boolResult : boolean;
begin
  boolResult := false;
  // Execute wmctrl -l -p to list windows with PIDs
  POpen(f, 'cat /etc/os-release', 'r');
  while not EOF(f) do
  begin
    ReadLn(f, line);
    if pos(windowStr,line) <> 0 then
    boolResult := true;
    // Parse 'line' to extract window ID, PID, OS or title as needed
    // Example: Split by spaces to identify specific windows
  end;
  Close(f);
  FindOSname := boolResult;
end;
//useful for finding out if we running under IDE
// needs wmctrl installed

function FindWindowLinux(windowStr: string): boolean;
    var
  f: Text;
  line: string;
  boolResult : boolean;
begin
  boolResult := false;
  // Execute wmctrl -l -p to list windows with PIDs
  POpen(f, 'wmctrl -l -p', 'r');
  while not EOF(f) do
  begin
    ReadLn(f, line);
    if pos(windowStr,line) <> 0 then
    boolResult := true;
    // Parse 'line' to extract window ID, PID, or title as needed
    // Example: Split by spaces to identify specific windows
  end;
  Close(f);
  FindWindowLinux := boolResult;
end;

{----------------------------------------------------
       Name: GetTodaysDate function
Declaration: GetTodaysDate: string;
       Unit: StrBox
       Code: S
       Date: 08/16/94
Description: Return a string of type MM/DD/YY.
/// added return the next days will return 1 = tommorow .. 2 every 2 days
-----------------------------------------------------}
function GetTodaysDate(incNumber: integer;separatorStr: string): string;
var
  y, m, d: Word;
  Year,DateTimeStr: string;
  myDate: tdatetime;
  x: integer;
begin
 //dateTimeStr := FormatDateTime('dd-mm-yyyy', MyDate);
 // mydate := formatdatetime('dd-mm-yyyy', MyDate)

  myDate := date;

  if incNumber > 0 then
  for x := 1 to incNumber do
        begin

  myDate  := incDay(mydate) ;

        end
  else
  myDate  := date;
  DecodeDate(myDate, y,m,d);
  Year := Int2StrPad0(y, 4);
  Delete(Year, 1, 2);
    if separatorStr = '/' then
  getTodaysDate := Int2StrPad0(d, 2) + '/' + Int2StrPad0(m, 2) + '/' + Year;
     if separatorStr = '-' then
  getTodaysDate := Int2StrPad0(d, 2) + '-' + Int2StrPad0(m, 2) + '-' + Year;
 //incDay(Date);
end;

function IsNumber(Ch: Char): Boolean;
begin
  IsNumber := ((Ch >= '0') and (Ch <= '9'));
end;

{----------------------------------------------------
       Name: LeftSet function
Declaration: LeftSet(src: string; Width: Integer;
                     var Trunc: Boolean): string;
       Unit: StrBox
       Code: S
       Date: 03/01/94
Description: Pad a string on the left
-----------------------------------------------------}
function LeftSet(src: string; Width: Integer; var Trunc: Boolean): string;
var
  I : Integer;
  Temp: string[80];
begin
  Trunc := False;
  Temp := src;
  if(Length(Temp) > Width) and (Width > 0) then begin
    Temp[0] := CHR(Width);
    Trunc := True;
  end else
    for i := Length(Temp) to width do
      Temp := Temp + ' ';
  LeftSet := Temp;
end;

{----------------------------------------------------
       Name: RemoveFirstWord function
Declaration: RemoveFirstWord(var S : string) : string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Strip the first word from a sentence,
             return word and a shortened sentence.
             Return an empty string if there is no
             first word.
-----------------------------------------------------}
function RemoveFirstWordAI(const S: string): string;
var
  FirstSpacePos: Integer;
begin
  // Find the position of the first space
  FirstSpacePos := Pos(' ', S);

  // If no space is found, the first word is the entire string
  // Return empty string or handle as needed
  if FirstSpacePos = 0 then
    Result := ''
  else
    // Return the substring starting after the first space
    Result := Copy(S, FirstSpacePos + 1, Length(S) - FirstSpacePos);
end;
function RemoveFirstWord(var S : string) : string;  overload  ;
var
  i, Size: Integer;
  S1: string;
begin
  i := Pos(#32, S);
  if i = 0 then begin
    RemoveFirstWord := '';
    Exit;
  end;
  if i = 1 then
   begin
 result := stripfromfront(s,1);
   exit;
   end;

  SetLength(S1, i);
  Move(S[1], S1[1], i);
  SetLength(S1, i-1);
  Size := (Length(S) - i);
  Move(S[i + 1], S[1], Size);
  SetLength(S, Size);
  RemoveFirstWord := S1;
end;
{
function rot13(sInput: string): string;

 const
  rot13a: array ['A'..'Z'] of Char = 'NOPQRSTUVWXYZABCDEFGHIJKLM';
  rot13b: array ['a'..'z'] of Char = 'nopqrstuvwxyzabcdefghijklm';
 rot13c: array ['0'..'9'] of Char = '9876543210';
    // rot13c: array ['0'..'9'] of Char ='(*&^%$#@!)';
   //  rot13d: array ['0'..'9'] of Char ='(*&^%$#@!)';
   //  rot13d: array ['*'..'&'] of Char ='9876543210';
var
  t: String;
  i,n: Integer;
begin

  t := sInput;
  for i := 1 to Length(t) do
    if t[i] in ['A'..'Z'] then
      t[i] := rot13a[t[i]]
    else if t[i] in ['a'..'z'] then
      t[i] := rot13b[t[i]];
  //    n:= length(rot13c);
   //   showmessage(inttostr(n));

  for i := 1 to Length(t) do
      if t[i] in ['0'..'9'] then
      t[i] := rot13c[t[i]]
      else if t[i] = ' ' then
      t[i] := char(randomrange(100,125));

  result := t;
end;  }

function RemoveFirstWord(var S : widestring) : widestring; overload     ;
var
  i, Size: Integer;
  S1: string;
begin
  i := Pos(#32, S);
  if i = 0 then begin
    RemoveFirstWord := '';
    Exit;
  end;
  SetLength(S1, i);
  Move(S[1], S1[1], i);
  SetLength(S1, i-1);
  Size := (Length(S) - i);
  Move(S[i + 1], S[1], Size);
  SetLength(S, Size);
  RemoveFirstWord := S1;
end;

{----------------------------------------------------
       Name: ReplaceString
Declaration: ReplaceString(NewStr, ReplaceStr, Data: string): string;
       Unit: StrBox
       Code: S
       Date: 06/06/95
Description: Given a long string, replace one substring with another.
             Take the string: "Football Delight"
             The job is to replace the word Delight with Night:
             S := ReplaceString(Night, Delight, 'Football Delight');
             where S ends up equaling "Football Night'; 
-----------------------------------------------------}
function ReplaceString(NewStr, ReplaceStr, Data: string): string;
var
  OffSet: Integer;
begin
  OffSet := Pos(ReplaceStr, Data);
  Delete(Data, OffSet, Length(ReplaceStr));
  Insert(NewStr, Data, OffSet);
  Result := Data;
end;

function ReplaceChars(S: string; OldCh, NewCh: Char): string;
var
  Len: Integer;
  i: Integer;
begin
  Len := Length(S);
  for i := 1 to Len do
    if S[i] = OldCh then
      S[i] := NewCh;
  Result := S;
end;


function rot13(S: string): string;
       const
  rot13a: array ['A'..'Z'] of Char = 'NOPQRSTUVWXYZABCDEFGHIJKLM';
  rot13b: array ['a'..'z'] of Char = 'nopqrstuvwxyzabcdefghijklm';
  rot13c: array ['0'..'9'] of Char = '9876543210';
var
  t: String;
  i: Integer;
begin
  t := S;
  for i := 1 to Length(t) do
    if t[i] in ['A'..'Z'] then
      t[i] := rot13a[t[i]]
    else if t[i] in ['a'..'z'] then
      t[i] := rot13b[t[i]]
      else if t[i] in ['0'..'9'] then
        t[i] := rot13c[t[i]];
 result := t;
end;

function ObfuStr(S: string): string;
var
Temp,temp2: string;
size: integer;
begin

temp := s;
temp2:= s;
size:= length(s);

temp := reversestr(temp);
//temp[1] := temp2[1];
//temp[size] := temp2[size];

{if size = 3 then
      begin
     temp := 'cat'
     end;    }
 result := temp;

end;

function ReverseStr(S: string): string;
var
  Len: Integer;
  Temp: string;
  i,j: Integer;
begin
  Len := Length(S);
  SetLength(Temp, Len);
  j := Len;
  for i := 1 to Len do begin
    Temp[i] := S[j];
    dec(j);
  end;
  ReverseStr := Temp;
end;

function RightCharSet(Src: string; Width: Integer;
                      Ch: Char; var Trunc: Boolean): string;
var
  I : Integer;
  Temp: string[80];
begin
  Trunc := False;
  Temp := Src;
  if(Length(Temp) > Width) and (Width > 0) then begin
    Temp[0] := CHR(Width);
    Trunc := True;
  end else
    for i := Length(Temp) to (width - 1) do
      Temp := Ch + Temp ;
  RightCharSet := Temp;
end;
//program rootls;

{ Demonstrates using TProcess, redirecting stdout/stderr to our stdout/stderr,
calling sudo on FreeBSD/Linux/macOS, and supplying input on stdin}
//{$mode objfpc}{$H+}

{uses
  Classes,
  Math, {for min}
  Process; }
function  myMin(a: Integer; b: Integer): integer;
begin
if a < b then
 Result := a
else
 Result := b;
 end;

  procedure RunsLsRoot;
  var
    Proc: TProcess;
    CharBuffer: array [0..511] of char;
    ReadCount: integer;
    ExitCode: integer;
    SudoPassword: string;
  begin
//    WriteLn('Please enter the sudo password:');
 //   Readln(SudoPassword);
  sudopassword := 'password';
    ExitCode := -1; //Start out with failure, let's see later if it works
    Proc := TProcess.Create(nil); //Create a new process
    try
      Proc.Options := [poUsePipes, poStderrToOutPut]; //Use pipes to redirect program stdin,stdout,stderr
      Proc.CommandLine := 'sudo -S ls /root'; //Run ls /root as root using sudo
      // -S causes sudo to read the password from stdin.
      Proc.Execute; //start it. sudo will now probably ask for a password

      // write the password to stdin of the sudo program:
      SudoPassword := SudoPassword + LineEnding;
      Proc.Input.Write(SudoPassword[1], Length(SudoPassword));
      SudoPassword := '%*'; //short string, hope this will scramble memory a bit; note: using PChars is more fool-proof
      SudoPassword := ''; // and make the program a bit safer from snooping?!?

      // main loop to read output from stdout and stderr of sudo
      while Proc.Running or (Proc.Output.NumBytesAvailable > 0) or
        (Proc.Stderr.NumBytesAvailable > 0) do
      begin
        // read stdout and write to our stdout
        while Proc.Output.NumBytesAvailable > 0 do
        begin
          ReadCount := myMin(512, Proc.Output.NumBytesAvailable); //Read up to buffer, not more
          Proc.Output.Read(CharBuffer, ReadCount);
          Write(StdOut, Copy(CharBuffer, 0, ReadCount));
        end;
        // read stderr and write to our stderr
        while Proc.Stderr.NumBytesAvailable > 0 do
        begin
          ReadCount := myMin(512, Proc.Stderr.NumBytesAvailable); //Read up to buffer, not more
          Proc.Stderr.Read(CharBuffer, ReadCount);
          Write(StdErr, Copy(CharBuffer, 0, ReadCount));
        end;
      end;
      ExitCode := Proc.ExitStatus;
    finally
      Proc.Free;
      Halt(ExitCode);
    end;
  end;
    {
begin
  RunsLsRoot;
end.        }
function Shorten(S: string; Cut: Integer): string;
begin
  SetLength(S, Length(S) - Cut);
  Shorten := S;
end;
  // strip the first chars from a string with count of number
function StripFirstNumberChars(S: string;number: Integer): string;
var
temp: string;
begin
temp := reverseStr(s);
temp := shorten(temp,number);
result := reverseStr(temp);
//
end;

// given a path like /home/strangeusernaem/Pascal/
 // you get /home/stra../Pasc../
function ShortenFilePath(S: string; os: integer): string;
var
shortStrA,shortStrB,shortStrC: string;
x:       integer;
begin
//
shortStrA := s;
shortStrB := '/';
 //for x := 0 to length(s) - 1 do
 while pos('/',shortStrA) <> 0 do
   begin
     shortstrA := stripfirsttoken(shortstrA,'/');
     shortStrC := getfirsttoken(shortStrA,'/');
     //  shortStrC := stripfirsttoken(shortStrC,'/');
     // delete(shortstrC,0,os);
             if length(shortstrC) > os+1 then
    shortStrC :=  shorten(shortStrC,os);
            // if length(shortstrc) > 5 then
            if shortStrC <> '' then
     shortStrB := shortStrB + shortStrC+'../'
            //  else
            //  shortStrB := ShortStrB + shortStrC+'/';
     end;
   result := shortStrB;
end;

procedure SplitDirName(Path : PathStr; var Dir: DirStr; var WName: Str12);
begin
  Dir := ExtractFilePath(Path);
  WName := ExtractFileName(Path);
end;
{
procedure SplitDirName(Path : PathStr; var Dir: DirStr; var WName: Str12);
begin
  FSplit(Path, Dir, Name, Ext);
  WName := ExtractFileName(Path);
end;
}

{----------------------------------------------------
       Name: StripBlanks function
Declaration: function StripBlanks(var S: string): string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Strip any stray spaces from the end of
             a string
-----------------------------------------------------}
function StripBlanks(S: string): string;
var
  i: Integer;
begin
  i := Length(S);
  while (Length(S) <= i) and (Length(S) > 0) and (S[i] = ' ') do begin
    Delete(S,i,1);
    Dec(i);
  end;
  StripBlanks := S;
end;

function StripEndChars(S: string; Ch: Char): string;
var
  i: Integer;
begin
  i := Length(S);
  while (length(S) > 0) and (S[i] = Ch) do begin
    Delete(S,i,1);
    Dec(i);
  end;
  StripEndChars := S;
end;


function StripFirstToken(S: string; Ch: Char): string;
var
  i, Size: Integer;
begin
  i := Pos(Ch, S);
  if i = 0 then begin
    StripFirstToken := S;
    Exit;
  end;
  Size := (Length(S) - i);
  Move(S[i + 1], S[1], Size);
  SetLength(S, Size);
  StripFirstToken := S;
end;

{----------------------------------------------------
       Name: StripFirstWord function
Declaration: StripFirstWord(S : string) : string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Strip the first word from a sentence,
             return the shortened sentence this requires the
             white space option. Else you can search for a string
             then return original
             string if there is no first word. x can be white space
             ie one blank character
             or a word.
-----------------------------------------------------}
function StripFirstWord(S : string;x:string) : string;
var
  i, Size: Integer;
begin
 // i := Pos(#32, S); for white space detection option comment out
 // next line and replace with this (also change parameter template
 // to char :)
 i := Pos(x,s);
  if i = 0 then begin
    StripFirstWord := S;
    Exit;
  end;
  Size := (Length(S) - i);
  Move(S[i + 1], S[1], Size);
  SetLength(S, Size);
  StripFirstWord := S;
end;
function StripHTMLTag(S : string;x:string) : string;
var
  i, Size: Integer;
begin
 // i := Pos(#32, S); for white space detection option comment out
 // next line and replace with this (also change parameter template
 // to char :)
 i := Pos(x,s);
  if i = 0 then begin
    StripHTMLTag := S;
    Exit;
  end;
  Size := (Length(S) - i);
  Move(S[i +1], S[1], Size);
  SetLength(S, Size);
  StripHTMLTag := S;
end;
{----------------------------------------------------
       Name: StripFrontChars function
Declaration: StripFrontChars(S: string; Ch: Char) : string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Strips any occurances of charact Ch that
             might precede a string.
-----------------------------------------------------}
function StripFrontChars(S: string; Ch: Char): string;
begin
  while (Length(S) > 0) and (S[1] = Ch) do
    S := Copy(S,2,Length(S) - 1);
  StripFrontChars := S;
end;

function StripFromFront(S: string; Len: Integer): string;
begin
  S := ReverseStr(S);
  S := Shorten(S, Len);
  S := ReverseStr(S);
  StripFromFront := S;
end;

{----------------------------------------------------
       Name: StripLastToken function
Declaration: function RemoveLastToken(var S: string): string;
       Unit: StrBox
       Code: S
       Date: 03/02/94
Description: Given a string like "c:\sam\file.txt"
             This returns: "c:\sam"
             But not specific to files any token will do
-----------------------------------------------------}
function StripLastToken(S: string; Token: Char): string;
var
  Temp: string;
  Index: INteger;
begin
  SetLength(Temp, Length(S));
  S := ReverseStr(S);
  Index := Pos(Token, S);
  Inc(Index);
  Move(S[Index], Temp[1], Length(S) - (Index - 1));
  SetLength(Temp, Length(S) - (Index - 1));
  StripLastToken := ReverseStr(Temp);
end;
// go through a list of strings and delete the last part of
// the string
function StripLastTokenList(SL: tstringList; Token: Char): tstringlist;
 var
   x: integer;
   s: string;
begin
  for x:= 0 to sl.count-1 do
          begin
            s := getfirsttoken(sl[x],token);
            if s <> '' then
         sl[x] :=  s;

          end;
  result := sl;
end;

end.


