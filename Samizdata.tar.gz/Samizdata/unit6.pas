unit Unit6;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls
  , DCPtiger, DCPsha512, DCPsha256, DCPsha1, DCPripemd160,
  DCPripemd128, DCPmd5, DCPmd4, DCPcrypt2, DCPhaval, DCPtwofish, DCPtea,
  DCPserpent, DCPblockciphers, DCPrijndael, DCPrc4, DCPrc2, DCPice, DCPdes,
  DCPcast128, DCPblowfish,ComCtrls,UnitUtilitaires,strbox3,inifiles;

type

  { TForm5 }

  TForm5 = class(TForm)
    boxPassphrase: TEdit;
    btnClose: TButton;
    btnDecrypt: TButton;
    btnEncrypt: TButton;
    btn_Copy: TButton;
    btn_Paste: TButton;
    cbxCipher: TComboBox;
    cbxHash: TComboBox;
    ckbPhraseShow: TCheckBox;
    dblKeySize: TLabel;
    grpOptions: TGroupBox;
    Label1: TLabel;
    lblCipher: TLabel;
    lblHash: TLabel;
    lblKeySize: TLabel;
    lblPassphrase: TLabel;
    lblPassView: TLabel;
    Memo1: TMemo;
    memSelect: TMemo;
    memSelect1: TMemo;
    OpenDialog1: TOpenDialog;
    Panel1: TPanel;
    Panel10: TPanel;
    Panel11: TPanel;
    Panel12: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    Panel4: TPanel;
    Panel5: TPanel;
    Panel6: TPanel;
    Panel7: TPanel;
    Panel8: TPanel;
    Panel9: TPanel;
    pnlClearPhrase: TPanel;
    pnlCopyPhrase: TPanel;
    Progress: TProgressBar;
    SaveDialog1: TSaveDialog;
    procedure boxPassphraseChange(Sender: TObject);
    procedure btnCloseClick(Sender: TObject);
    procedure btnDecryptClick(Sender: TObject);
    procedure btnEncryptClick(Sender: TObject);
    procedure btn_CopyClick(Sender: TObject);
    procedure btn_PasteClick(Sender: TObject);
    procedure cbxCipherChange(Sender: TObject);
    procedure ckbPhraseShowChange(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Panel10Click(Sender: TObject);
    procedure Panel11Click(Sender: TObject);
    procedure Panel12Click(Sender: TObject);
    procedure Panel4Click(Sender: TObject);
    procedure Panel5Click(Sender: TObject);
    procedure Panel7Click(Sender: TObject);
    procedure pnlClearPhraseClick(Sender: TObject);
    procedure pnlCopyPhraseClick(Sender: TObject);
    procedure Pourcentage(Sender: TObject; Value: integer);
  private
     procedure DisableForm;
     Procedure WriteINIstr(Main,Sub,Value: string);
     Function ReadINIstr(Main,Sub: string): string;
     function DoEncryptStringStream(passphrase: string;
             Hash: TDCP_hash; Cipher: TDCP_cipher): Boolean;
      function DoDecryptStringStream(passphrase: string;
                        Hash: TDCP_hash; Cipher: TDCP_cipher): Boolean;
  public

  end;

var
  Form5: TForm5;
  ConvertRunning: boolean;

implementation
uses
  unit1;

{$R *.lfm}

{ TForm5 }
Procedure TForm5.WriteINIstr(Main,Sub,Value: string);
var
  INI: tinifile;
  begin
     INI :=   tinifile.create(form1.Hint);
      Ini.WriteString(Main, Sub, Value);
  end;
Function TForm5.ReadINIstr(Main,Sub: string): string;
var
  INI: tinifile;
  Str: string;
  begin
    INI :=  tinifile.create(form1.Hint);
str := Ini.ReadString(Main, Sub,'12');
  result := str
  end;
function Min(a, b: integer): integer;
begin
  if (a < b) then
    Result := a
  else
    Result := b;
end;
function Tform5.DoDecryptStringStream(passphrase: string;
                        Hash: TDCP_hash; Cipher: TDCP_cipher): Boolean;
var
  CipherIV: array of byte;
  HashDigest: array of byte;
  Salt: array[0..7] of byte;
  strmInput, strmOutput: TStringStream;
begin
  Result := True;
  strmInput := nil;
  strmOutput := nil;
  try
    strmInput := TStringStream.Create(HexToString(Trim(Memo1.Text)));
    strmOutput := TStringStream.Create('');

    SetLength(HashDigest, Hash.HashSize div 8);
    strmInput.ReadBuffer(Salt[0], SizeOf(Salt));
    Hash.Init;
    Hash.Update(Salt[0], SizeOf(Salt));
    Hash.UpdateStr(passphrase);
    Hash.Final(HashDigest[0]);

    if (Cipher is TDCP_blockcipher) then
    begin
      SetLength(CipherIV, TDCP_blockcipher(Cipher).BlockSize div 8);
      strmInput.ReadBuffer(CipherIV[0], Length(CipherIV));
      Cipher.Init(HashDigest[0], Min(Cipher.MaxKeySize, Hash.HashSize), @CipherIV[0]);
      TDCP_blockcipher(Cipher).CipherMode := cmCBC;
    end
    else
      Cipher.Init(HashDigest[0], Min(Cipher.MaxKeySize, Hash.HashSize), nil);

    Cipher.DecryptStream(strmInput, strmOutput, strmInput.Size - strmInput.Position);
    Cipher.Burn;
    strmOutput.Position := 0;
    Memo1.Text := strmOutput.DataString;
    strmInput.Free;
    strmOutput.Free;
    ConvertRunning := False;
  except
    strmInput.Free;
    strmOutput.Free;
    ConvertRunning := False;
  end;
end;

procedure Tform5.Pourcentage(Sender: TObject; Value: integer);
begin
  if Value <= 100 then
    if Value >= 0 then
      Progress.Position := Value;
end;

function Tform5.DoEncryptStringStream(passphrase: string;
                        Hash: TDCP_hash; Cipher: TDCP_cipher): Boolean;
var
  CipherIV: array of byte;
  HashDigest: array of byte;
  Salt: array[0..7] of byte;
  strmInput, strmOutput: TStringStream;
  i: integer;
begin
  Result := True;
  strmInput := nil;
  strmOutput := nil;
  Cipher.OnProgressEvent := @Pourcentage;
  try
    strmInput := TStringStream.Create(Memo1.Text);
    strmOutput := TStringStream.Create('');

    SetLength(HashDigest, Hash.HashSize div 8);
    for i := 0 to 7 do
      Salt[i] := Random(256);
    strmOutput.WriteBuffer(Salt, SizeOf(Salt));
    Hash.Init;
    Hash.Update(Salt[0], SizeOf(Salt));
    Hash.UpdateStr(passphrase);
    Hash.Final(HashDigest[0]);

    if (Cipher is TDCP_blockcipher) then
    begin
      SetLength(CipherIV, TDCP_blockcipher(Cipher).BlockSize div 8);
      for i := 0 to (Length(CipherIV) - 1) do
        CipherIV[i] := Random(256);
      strmOutput.WriteBuffer(CipherIV[0], Length(CipherIV));
      Cipher.Init(HashDigest[0], Min(Cipher.MaxKeySize, Hash.HashSize), @CipherIV[0]);
      TDCP_blockcipher(Cipher).CipherMode := cmCBC;
    end
    else
      Cipher.Init(HashDigest[0], Min(Cipher.MaxKeySize, Hash.HashSize), nil);

    Cipher.EncryptStream(strmInput, strmOutput, strmInput.Size);
    Cipher.Burn;
    strmOutput.Position := 0;
    Memo1.Text := StringToHex(strmOutput.DataString);
    strmInput.Free;
    strmOutput.Free;
    ConvertRunning := False;
  except
    strmInput.Free;
    strmOutput.Free;
    ConvertRunning := False;
  end;
end;

procedure TForm5.btnCloseClick(Sender: TObject);
begin
  form5.hide;
end;

procedure TForm5.boxPassphraseChange(Sender: TObject);
begin
     if (Length(boxPassphrase.Text) > 0) then
  begin
    btnEncrypt.Enabled := True;
    btnDecrypt.Enabled := True;
  end
  else
  begin
    btnEncrypt.Enabled := False;
    btnDecrypt.Enabled := False;
  end;
end;

procedure TForm5.btnDecryptClick(Sender: TObject);
var
  Hash: TDCP_hash;
  Cipher: TDCP_cipher;
begin
  if ConvertRunning then Exit;
  if Trim(Memo1.Text) = '' then Exit;
  if not IsHex(Trim(Memo1.Text)) then Exit;
  ConvertRunning := True;
  Progress.Position := 0;
  Hash := TDCP_hash(cbxHash.Items.Objects[cbxHash.ItemIndex]);
  Cipher := TDCP_cipher(cbxCipher.Items.Objects[cbxCipher.ItemIndex]);
  DoDecryptStringStream(boxPassphrase.Text, Hash, Cipher);
end;

procedure TForm5.btnEncryptClick(Sender: TObject);
var
  Hash: TDCP_hash;
  Cipher: TDCP_cipher;
begin
  if ConvertRunning then Exit;
  if Trim(Memo1.Text) = '' then Exit;

  ConvertRunning := True;
  Progress.Position := 0;

  Hash := TDCP_hash(cbxHash.Items.Objects[cbxHash.ItemIndex]);
  Cipher := TDCP_cipher(cbxCipher.Items.Objects[cbxCipher.ItemIndex]);
  DoEncryptStringStream(boxPassphrase.Text, Hash, Cipher);

end;

procedure TForm5.btn_CopyClick(Sender: TObject);
begin
    Memo1.SelectAll;
  Memo1.CopyToClipboard;
end;

procedure TForm5.btn_PasteClick(Sender: TObject);
begin
    Memo1.Clear;
  Memo1.PasteFromClipboard;
end;

procedure TForm5.cbxCipherChange(Sender: TObject);

  var
    Cipher: TDCP_cipher;
    Hash: TDCP_hash;
  begin
    Cipher := TDCP_cipher(cbxCipher.Items.Objects[cbxCipher.ItemIndex]);
    Hash := TDCP_hash(cbxHash.Items.Objects[cbxHash.ItemIndex]);
    if (Cipher.MaxKeySize < Hash.HashSize) then
      dblKeySize.Caption := IntToStr(Cipher.MaxKeySize) + ' bits'
    else
      dblKeySize.Caption := IntToStr(Hash.HashSize) + ' bits';
  end;

procedure TForm5.ckbPhraseShowChange(Sender: TObject);
begin
  lblPassView.Visible := not lblPassView.Visible;
end;

procedure TForm5.DisableForm;
begin
  grpOptions.Enabled := False;
  btnEncrypt.Enabled := False;
  btnDecrypt.Enabled := False;
end;
procedure TForm5.FormCreate(Sender: TObject);
var
  i: integer;
begin
     // -- Ciphers --
  TDCP_blowfish.Create(Self);
  TDCP_cast128.Create(Self);
  TDCP_des.Create(Self);
  TDCP_3des.Create(Self);
  TDCP_ice.Create(Self);
  TDCP_thinice.Create(Self);
  TDCP_ice2.Create(Self);
  TDCP_rc2.Create(Self);
  TDCP_rc4.Create(Self);
  TDCP_rijndael.Create(Self);
  TDCP_serpent.Create(Self);
  TDCP_tea.Create(Self);
  TDCP_twofish.Create(Self);

  // -- Hashes --
  TDCP_haval.Create(Self);
  TDCP_md4.Create(Self);
  TDCP_md5.Create(Self);
  TDCP_ripemd128.Create(Self);
  TDCP_ripemd160.Create(Self);
  TDCP_sha1.Create(Self);
  TDCP_sha256.Create(Self);
  TDCP_sha384.Create(Self);
  TDCP_sha512.Create(Self);
  TDCP_tiger.Create(Self);

  // Iterate through all owned components and find the ciphers/hashes
  for i := 0 to (ComponentCount - 1) do
  begin
    if (Components[i] is TDCP_cipher) then
      cbxCipher.Items.AddObject(TDCP_cipher(Components[i]).Algorithm, Components[i])
    else if (Components[i] is TDCP_hash) then
      cbxHash.Items.AddObject(TDCP_hash(Components[i]).Algorithm, Components[i]);
  end;

  if (cbxCipher.Items.Count = 0) then
  begin
    MessageDlg('No ciphers were found', mtError, [mbOK], 0);
    DisableForm;
  end
  else
  begin
    cbxCipher.ItemIndex := 0;
    if (cbxHash.Items.Count = 0) then
    begin
      MessageDlg('No hashes were found', mtError, [mbOK], 0);
      DisableForm;
    end
    else
    begin
      cbxHash.ItemIndex := 0;
      cbxCipher.OnChange(cbxCipher);
    end;
  end;
end;

procedure TForm5.FormShow(Sender: TObject);
begin
    form5.Top := 0;
    form5.Left := 0;
    form5.Height := form1.height;// - panel1.height;
    form5.width := screen.width;
end;

procedure TForm5.Panel10Click(Sender: TObject);
begin
  memo1.clear;
end;

procedure TForm5.Panel11Click(Sender: TObject);
begin
  writeINIstr('Main','ProductCode',boxpassphrase.Text);
end;

procedure TForm5.Panel12Click(Sender: TObject);
begin
   boxpassphrase.text :=     readINIstr('Main','ProductCode');
     if ckbPhraseShow.checked = true then
     lblPassView.caption := boxpassphrase.text;
end;

procedure TForm5.Panel4Click(Sender: TObject);
begin
  opendialog1.InitialDir := GetAppConfigDir(False);
  if opendialog1.Execute = true then
           memo1.Lines.loadfromfile(opendialog1.FileName);
end;

procedure TForm5.Panel5Click(Sender: TObject);
begin
  savedialog1.InitialDir := GetAppConfigDir(False);
   if savedialog1.Execute = true then
           memo1.Lines.savetofile(opendialog1.FileName);
end;

procedure TForm5.Panel7Click(Sender: TObject);
begin
  if memo1.Tag = 0 then
          begin
             boxpassphrase.Text := boxpassphrase.Text + reversestr(datetostr(now));
            memo1.tag := 1;
          end
  else
          begin
             if panel7.Tag = 0 then
                  begin
             boxpassphrase.Text := boxpassphrase.Text + reversestr(timetostr(now));
                  panel7.tag := 1;
                  end
             else
                  begin
              boxpassphrase.Text := boxpassphrase.Text + timetostr(now);
                  panel7.tag := 0;
                  end;
             memo1.tag := 0;
          end;

  lblPassView.Caption := boxpassphrase.text;
end;

procedure TForm5.pnlClearPhraseClick(Sender: TObject);
begin
  boxpassphrase.Text := '';
  lblPassView.Caption := '';
end;

procedure TForm5.pnlCopyPhraseClick(Sender: TObject);
begin
  if boxpassphrase.text = '' then
  begin
  showmessage('Nothing to copy');
  exit;
  end;
  memSelect.visible := true;
  showmessage('Will copy passphrase to bottom of screen, it does this as '+#13+
  'plain text so take precaution if in public area, right click, select all,'
  +#13+'and then right click copy');
  memSelect.text := boxpassphrase.text;
  memSelect.SelectAll;
  memSelect.CopyToClipboard;
end;

end.

