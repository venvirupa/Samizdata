unit Unit5;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls;

type

  { TForm4 }

  TForm4 = class(TForm)
    Memo1: TMemo;
    Panel1: TPanel;
    procedure Panel1Click(Sender: TObject);
  private

  public

  end;

var
  Form4: TForm4;

implementation
uses
  unit1;

{$R *.lfm}

{ TForm4 }

procedure TForm4.Panel1Click(Sender: TObject);
begin
  form1.timer1.Enabled := false;
  form4.hide;
end;

end.

