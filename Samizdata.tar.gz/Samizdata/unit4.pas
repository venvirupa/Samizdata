unit Unit4;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  strbox3,inifiles,unit6;

type

  { TForm3 }

  TForm3 = class(TForm)
    Edit1: TEdit;
    Memo1: TMemo;
    OpenDialog1: TOpenDialog;
    Panel1: TPanel;
    Panel10: TPanel;
    Panel11: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    Panel4: TPanel;
    Panel5: TPanel;
    Panel6: TPanel;
    Panel7: TPanel;
    Panel8: TPanel;
    Panel9: TPanel;
    SaveDialog1: TSaveDialog;
    procedure FormShow(Sender: TObject);
    procedure Panel10Click(Sender: TObject);
    procedure Panel11Click(Sender: TObject);
    procedure Panel2Click(Sender: TObject);
    procedure Panel3Click(Sender: TObject);
    procedure Panel4Click(Sender: TObject);
    procedure Panel5Click(Sender: TObject);
    procedure Panel6Click(Sender: TObject);
    procedure Panel7Click(Sender: TObject);
    procedure Panel8Click(Sender: TObject);
  private
   procedure PanelFormClick(Sender: TObject);
  public

  end;

var
  Form3: TForm3;

implementation
uses
  unit1;

{$R *.lfm}

{ TForm3 }
procedure Tform3.PanelFormClick(Sender: TObject);
begin
     if edit1.caption = '000000' then
     edit1.caption := '';
     edit1.Caption := edit1.Caption + tpanel(sender).Caption;
     Edit1.SelStart := Length(Edit1.Text);
Edit1.SelLength := 0;
end;

procedure TForm3.FormShow(Sender: TObject);
var
  x,y,z: integer;
  panelx,panely: tpanel;      //443556 = 666 * 666
begin
      panel1.DestroyComponents;
      z := 0;
      for x := 0 to 4 do
      begin

      panelx := tpanel.create(panel1);
      panelx.parent := panel1;
      panelx.align  := altop;

          for y := 0 to 2 do
              begin
              panely := tpanel.create(panelx);
               panely.parent := panelx;
               panely.align  := alLeft;
               if odd(y) then
               panely.Color := clblack
               else
               panely.color := clnavy;
              if z < 10 then
               panely.caption := inttostr(z);

               if z = 10 then
               panely.caption := '.';

               if z = 11 then
                panely.caption := 'x';

                 if z = 12 then
                panely.caption := '/';

                 if z = 13 then
                 panely.caption := '-';
                  if z = 14 then
                 panely.caption := '+';
               z := z +1;
               panely.OnClick := @panelFormClick;
               end;

      end;
end;

procedure TForm3.Panel10Click(Sender: TObject);
begin
  edit1.Caption := inttostr(strtoint(edit1.caption)*strtoint(edit1.caption));
end;

procedure TForm3.Panel11Click(Sender: TObject);
begin
  if opendialog1.execute then
  memo1.Lines.LoadFromFile(opendialog1.filename);
end;

procedure TForm3.Panel2Click(Sender: TObject);
begin
    // edit1.visible := true;
     memo1.Visible := false;
     panel2.visible := true;
      panel5.visible := false;
      panel9.visible := true;
  edit1.text := '000000';
  form3.Hide;
end;

procedure TForm3.Panel3Click(Sender: TObject);
var
  xs,ys,s2: string;
  x    : integer;
  value: longint;
  //memo1: tmemo;
  ini  : tinifile;
begin
  ini := tinifile.Create(form1.Hint);
  s2  := ini.ReadString('Main','Handle','1234321\,.a.,\media');
 // Ini.ReadString('Main', 'exec'+inttostr(x), 'Unknown'+inttostr(x)+'.
     if edit1.Caption =  s2 then
          begin
            form5.show;
        {  form3.Top := 0;
          form3.left := 0;
          form3.width := screen.Width;
          form3.Height := screen.height;
          panel2.visible := false;
          panel9.visible := false;
          memo1.Visible := true;
          panel1.DestroyComponents;
          memo1 := tmemo.Create(panel1);

          memo1.Parent := panel1;
          memo1.color := clBlack;
          memo1.Align  := alClient;
          memo1.ScrollBars := ssBoth;

          if fileexists('secret.txt') then
          memo1.Lines.LoadFromFile('secret.txt');
          panel5.visible := true; }
          end;
  if pos('x' , edit1.Caption) <> 0 then
  begin
    xs := getfirsttoken(edit1.caption,'x');
    ys := getlasttoken(edit1.caption,'x');
    if trystrtoint(xs,value) = true and trystrtoint(ys,value) = true then
    x  := strtoint(xs)*strtoint(ys);
    edit1.caption := inttostr(x);
  end;

  if pos('+' , edit1.Caption) <> 0 then
  begin
    xs := getfirsttoken(edit1.caption,'+');
    ys := getlasttoken(edit1.caption,'+');
    x  := strtoint(xs)+strtoint(ys);
    edit1.caption := inttostr(x);
  end;
    if pos('-' , edit1.Caption) <> 0 then
    begin
    xs := getfirsttoken(edit1.caption,'-');
    ys := getlasttoken(edit1.caption,'-');
    x  := strtoint(xs)-strtoint(ys);
    edit1.caption := inttostr(x);
  end;
   if pos('/' , edit1.Caption) <> 0 then
     begin
    xs := getfirsttoken(edit1.caption,'/');
    ys := getlasttoken(edit1.caption,'/');
    x  := strtoint(xs) div strtoint(ys);
    edit1.caption := inttostr(x);
  end;
end;

procedure TForm3.Panel4Click(Sender: TObject);
begin
  edit1.Caption := '000000';
end;

procedure TForm3.Panel5Click(Sender: TObject);
begin
  edit1.visible := true;
  memo1.Visible := false;
  panel2.visible := true;
  panel5.visible := false;
  panel9.visible := true;
  edit1.text := '000000';
  form3.hide;
end;

procedure TForm3.Panel6Click(Sender: TObject);

 // memox: tmemo;
begin
//tcomponent(memox) := findcomponent('memo1') ;
 memo1.text := extendedrot13(memo1.text);
end;

procedure TForm3.Panel7Click(Sender: TObject);
begin
 //  memo1.text := extendedrot13(memo1.text);
 if edit1.text = '1234321' then
 edit1.Text  := edit1.text+extendedrot13(edit1.text)+'media'
 else
   edit1.text := inttostr(strtoint(edit1.text)+strtoint(edit1.text));
end;

procedure TForm3.Panel8Click(Sender: TObject);
begin
   if savedialog1.Execute then
   begin
       memo1.Lines.SaveToFile(savedialog1.filename);
   end;

end;

end.

