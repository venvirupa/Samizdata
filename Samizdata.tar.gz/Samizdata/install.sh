mkdir ~/.config/samizdata
cp settingsMint.ini ~/.config/samizdata
