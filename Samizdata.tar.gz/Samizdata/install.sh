mkdir ~/.config/samizdata
cp settingsMint.ini ~/.config/samizdata
cp *.txt ~/.config/samizdata
