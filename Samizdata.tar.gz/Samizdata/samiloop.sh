#!/bin/bash
# /usr/local/bin/samiloop.sh

while true; do
    # Replace with your actual program command
    #/home/stephenp/Downloads/Samizdata/samizdata
pgrep -x samizdata  >/dev/null || /home/stephenp/Downloads/Samizdata/samizdata
    sleep 10
done
