unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, extctrls, StdCtrls,
  ComCtrls, Menus,strbox3,inifiles,fileutil,unit3,unit4,unit5, LResources,netwm;

type

  { TForm1 }

  TForm1 = class(TForm)
    FontDialog1: TFontDialog;
    Image1: TImage;
    Image2: TImage;
    MenuItem1: TMenuItem;
    MenuItem3: TMenuItem;
    Panel1: TPanel;
    Panel10: TPanel;
    Panel11: TPanel;
    Panel12: TPanel;
    Panel13: TPanel;
    Panel14: TPanel;
    Panel15: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    Panel4: TPanel;
    Panel5: TPanel;
    Panel6: TPanel;
    Panel7: TPanel;
    Panel8: TPanel;
    Panel9: TPanel;
    PopupMenu1: TPopupMenu;
    Timer1: TTimer;
    Timer2: TTimer;
    TimerArch: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure Image2Click(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure Panel10Click(Sender: TObject);
    procedure Panel11Click(Sender: TObject);
    procedure Panel12Click(Sender: TObject);
    procedure Panel13Click(Sender: TObject);
    procedure Panel15Click(Sender: TObject);

    procedure Panel1Click(Sender: TObject);
    procedure Panel1Paint(Sender: TObject);
    procedure Panel2Click(Sender: TObject);
    procedure Panel4Click(Sender: TObject);
    procedure Panel5Click(Sender: TObject);
    procedure Panel6Click(Sender: TObject);
    procedure Panel7Click(Sender: TObject);
    procedure Panel8Click(Sender: TObject);
    procedure Panel9Click(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure Timer2Timer(Sender: TObject);
    procedure TimerArchTimer(Sender: TObject);

  private
     procedure CreatePanels;
     function  CreateText(slx: tstringlist): tstringlist;
     function CreateHints(slx: tstringlist): tstringlist;
     function CreateBars(parentPan: tPanel): tpanel;
     function CreateOptionButton(bName,bCap: string; panParent: tpanel; col: integer): tPanel;
      procedure PanelClick(Sender: TObject);
      procedure LoadOSini(inistr: string);
      Procedure WriteINIstr(Main,Sub,Value: string);
      Function  ReadINIstr(Main,Sub: string): string;
  public

  end;

var
  Form1: TForm1;
//  imgBrush: timage;
  //iniNameMintArch:  string;
 // oldExeSize: integer;
//  panel2: tpanel;

implementation



{$R *.lfm}

{ TForm1 }
procedure TForm1.PanelClick(Sender: TObject);
var
  s: string;
  sl: tstringlist;
  x,oldsize: integer;
  begin
     sl := tstringlist.Create;
    s := tpanel(sender).hint;
    if s = 'Proc' then
    begin
       if findosname('CachyOS') then
           begin
              form3.Top := 0;
              form3.left := 0;
              form3.width := screen.width;
              form3.Panel9.Visible := false;
              form3.height := form1.height - (panel1.height);
       form3.show;

       timer1.Enabled := not timer1.enabled;
       exit;
           end;
       timer1.Enabled := not timer1.enabled;
     // windowmanager.showdesktop(false);
     // windowmanager.Fullscreen(form1.handle);
   //  windowmanager.showdesktop(false);
       form1.paint;
       exit;
    end;
    if s = 'calculator' then
       begin
       if findOSname('Mint') then
          form3.show;
   //executeCmdDetach('gnome-calculator',sl);
        if findOSname('Arch') then
    form3.show;
       exit;
       end;

    if tpanel(sender).helpkeyword = 'Brave' then
    begin
        if findOSname('Mint') then
   executeCmdDetach('brave-browser',sl);
           if findOSname('Arch') then
   executeCmdDetach('brave',sl);

       exit;
    end;
    if tpanel(sender).helpkeyword = 'SuspN' then
        begin
    form2.show;
    form2.timer1.enabled := true;
        end;
         //  gnome-terminal -- bash -c
     executeCmdDetach(lowercase(s),sl);


  end;
procedure TForm1.LoadOSini(inistr: string);
    var
  ini: tinifile;
  loadstr: string;
begin
  //
   loadStr := iniStr;
    Ini := TIniFile.Create(loadStr);
end;
Procedure TForm1.WriteINIstr(Main,Sub,Value: string);
var
  INI: tinifile;
  begin
     INI :=   tinifile.create(form1.Hint);
      Ini.WriteString(Main, Sub, Value);
  end;
Function TForm1.ReadINIstr(Main,Sub: string): string;
var
  INI: tinifile;
  Str: string;
  begin
    INI :=  tinifile.create(form1.Hint);
str := Ini.ReadString(Main, Sub,'12');
  result := str
  end;


procedure TForm1.FormCreate(Sender: TObject);
var
  iniNameMintArch: string;
  sl: tstringlist;
  s,s2,userPath : string;
  ResStream: TLazarusResourceStream;
begin
    s := expandfilename('~');
   s2:= getcurrentdir;
   if readinistr('Main','ConfigLock') = '1' then
   popupmenu1.autopopup := false;
    userPath := GetAppConfigDir(False) ;
    if not DirectoryExists(userPath) then
    ForceDirectories(userPath);
  if findosname('Mint') then
         begin

   ininameMintArch := s+'/.config/'+ExtractFileName(Application.ExeName)+'/settingsMint.ini';
             if not fileexists(ininameMintArch) then
                     begin
                       // showmessage('Can not find settings file at '+ininameMintArch+
                       // ', so have created a temporary one in the current directory and will extract and copy it.'
                      //   +#13+'Please copy it to the correct location. I have created an install script in the '+s2+' directory');
                           sl := tstringlist.Create;
                            sl.Add('mkdir '+'~/.config/'+extractfilename(application.exename));
                            sl.add('cp settingsMint.ini '+'~/.config/'+extractfilename(application.exename));
                            sl.SaveToFile('install.sh');
                        ResStream := TLazarusResourceStream.Create('settingsMint', nil);
                        //mkdir(ExtractFilePath(Application.ExeName));


                        if directoryexists(userpath) then
                           ResStream.SaveToFile(userpath+'settingsMint.ini')
                          else
                            ResStream.SaveToFile('settingsMint.ini'); // user has to figure out


                        ininameMintArch := 'settingsMint.ini';
                     end;
         end;
   if findosname('CachyOS') then
         begin
             s := expandfilename('~');
   ininameMintArch := s+'/.config/'+ExtractFileName(Application.ExeName)+'/settingsArch.ini';

          if not fileexists(ininameMintArch) then
                     begin
                //     showmessage('Can not find settings file at '+ininameMintArch+
                //        ', so have created a temporary one in the current directory.'
                //         +#13+'Please copy it to the correct location. I have created an install script in the '+s2+' directory');
                           sl := tstringlist.Create;
                            sl.Add('mkdir '+'~/.config/'+extractfilename(application.exename));
                            sl.add('cp settingsArch.ini '+'~/.config/'+extractfilename(application.exename));
                            sl.SaveToFile('install.sh');

                     ResStream := TLazarusResourceStream.Create('settingsArch', nil);
                        //mkdir(ExtractFilePath(Application.ExeName));
                         if directoryexists(userpath) then
                          ResStream.SaveToFile(userpath+'settingsArch.ini')
                          else
                        ResStream.SaveToFile('settingsArch.ini');  //user has to figure out problem
                        ininameMintArch := 'settingsArch.ini';
                     end;
         timerArch.enabled := true;
         end;
  // for debug timer1.Enabled := true;
   // use the hint string in the form as a global variable to hold INI file/path
  form1.Hint := iniNameMintArch;
  form1.top := 0;
  form1.left := screen.width div 2;
  form1.Height := screen.height;// div 2;
  form1.width := screen.width;// div 2;
  createPanels;
      form1.canvas.Font.Color := clyellow;
      form1.Font.Size := strtoint(readINIstr('Main','FontSize'));
   form1.canvas.Font.Style := [fsBold];
   form1.canvas.Brush.Style := bsClear;

   //form1.Canvas.TextOut(50,50,iniNameMintArch);
   //  sl :=  executersynccommand('top -b -n 1',sl);
   //  imgBrush := timage.Create(form1);
   //  imgBrush.picture.Bitmap.LoadFromFile('ape.bmp');
end;

//use hints in the panel to hold the actual exec path etc
function tform1.createHints(slx: tstringlist): tstringlist;
var
slHint:tstringlist;
ini:  tinifile;
x:     integer;
begin
   slHint := tstringlist.create;
   if  fileexists(form1.hint) then
     ini := tinifile.Create(form1.hint);
       for x := 0 to slx.count - 1 do
         // if pos(slxtra[x],'name') <> 0 then
          slHint.add(Ini.ReadString('Main', 'exec'+inttostr(x), 'Unknown'+inttostr(x)+'.txt'));
         result := slHint;
end;
// create text captions for buttons
function tform1.createText(slx: tstringlist): tstringlist;
var
   sl,slxtra: tstringlist;
   x: integer;
   ini: tinifile;
begin
  sl := tstringlist.Create;
  slxtra := tstringlist.create;
 if  fileexists(form1.hint) then
  ini := tinifile.Create(form1.hint);
//  for x := 0 to 29
 if not fileexists(form1.hint) then
           begin
  sl.Add('UFC');  //1
  sl.Add('Tar'); //2
  sl.Add('Find');   //3
  sl.Add('VLC');   //4
  sl.Add('Office');   //5
  sl.add('Xarc');  //6
  sl.add('GhosTTY');   //7
  sl.add('LoSend'); //8
  sl.add('Text');     //9
  sl.add('Build');    //10
  sl.add('Fish');    //11
  sl.add('FireF');   //12
  sl.add('Proc');     //13
  sl.add('Startup');     //14
  sl.add('Disks');     //15
  sl.add('TTY');     //16
  sl.add('Gimp');      //17
  sl.add('Rsync');     //18
  sl.add('Remind');    //19
  sl.add('VBox');    //20
   sl.add('Calendar');    //21
  sl.add('Btop');   //22
  sl.add('Calculator');     //23
  sl.add('Crypt');     //24
  sl.add('Schedule');       //25
  sl.add('Lazza');     //26
  sl.add('Scanner');      //27
  sl.add('NetCat');     //28
  sl.add('Okular');    //29
  sl.add('Brave');    //30    }
          end
 else
         begin
          slxtra.loadfromfile(form1.hint);

          for x := 0 to slxtra.Count - 1 do
         // if pos(slxtra[x],'name') <> 0 then
          sl.add(Ini.ReadString('Main', 'name'+inttostr(x), 'Button'+inttostr(x)+'.txt'));
          form1.Font.size; strtoint(ini.readstring('Main','FontSize','12'));

         // sl.add(getlasttoken(slxtra[x],'='));

         end;

 // sl.Reverse;
 // sl notes, sort sorts in reverse order
 // so i invert the display order by using
 // downto in the x = 9 downto 0 later

 // sl.Sort;
   // just make a basic INI file we can use
   // depending on the OS we are on

   {if not fileexists('settingsMint.ini') then
  sl.SaveToFile('settingsMint.ini');
  if not fileexists('settingsArch.ini') then
  sl.SaveToFile('settingsArch.ini');    }

 //  end;

  result := sl;
end;

function tform1.CreateBars(parentPan: tPanel): tpanel;
var
  panelCon,panelx: tpanel;
begin
   panelCon := tpanel.create(parentPan);
  panelCon.Parent := parentPan;
  panelCon.Color := $000F0F53;
  panelCon.align := altop;
  panelCon.Height := strtoint(ReadINIstr('Main','ButtonHeight'));
  if panelCon.Height < screen.height div 30
  then panelCon.height := screen.height div 30;
  panelcon.tag := 1;
  panelcon.OnPaint :=   @panel1paint;
   panelx := tpanel.Create(panelCon);
               panelx.Parent := panelCon;
                panelx.Align :=  alRight;
                panelx.showhint := true;
                panelx.Caption := 'Config';
                panelx.color := clBlack;
                panelx.OnClick := @panel7click;
                panelx.Font.Color := clgray;
{  if findosname('CachyOS') then
   panelCon.Height := panelCon.Height div 2;  }
  result := panelCon;
end;

procedure tform1.CreatePanels;
var
  x,y: integer;
  panelx,panelCon: tpanel;
  oddColor,EvenColor: tcolor;
  sl,sl2: tstringlist;
begin
  sl :=  tstringlist.Create;
  sl2 := tstringlist.Create;
  sl :=    createText(sl);
  sl2 := createHints(sl);
  panel1.Height := (strtoint(ReadINIstr('Main','ButtonHeight')))*4;
  // y creates 3 horizontal button bars then the x loop creates 10 buttons on
  // each of them
 for y := 0 to 2
  do
        begin
           if odd(y) then
              evenColor := $00214621;
           if odd(y) then
              oddcolor  := $00800040;
           if not odd(y) then
              evenColor := $00800040;
           if not odd(y) then
              oddcolor  := $00214621;

  panelCon := createbars(panel1);
  if odd(y) then
     begin
     panelCon.Caption := 'Show Options';
     panelCon.Alignment := taRightJustify;
     panelCon.Color := clblack;
     panelCon.OnClick := @panel7click;
     end;
   for x := 9 downto 0 do
            begin
              panelx := tpanel.Create(panelCon);
               panelx.Parent := panelCon;
                panelx.Align :=  alLeft;
                panelx.showhint := true;
                panelx.width := strtoint(ReadINIstr('Main','ButtonWidth'));
                if panelx.width < (screen.width div 12) then
                   panelx.width := (screen.width div 12);
                //if findosname('CachyOS') then
                //   panelx.Width := panelx.Width div 2;
                panelx.OnClick := @panelclick;
                 panelx.OnPaint :=   @panel1paint;
                 if odd(x) then panelx.Tag := 0
                    else
                      panelx.Tag := 1;
               // panelx.Font.Color := clYellow;
                if y = 0 then
                   begin
                panelx.helpkeyword := sl[x];
                panelx.hint    := sl2[x];
                   end;
               if y = 1 then
                   begin
                panelx.helpkeyword := sl[x+10];
                panelx.hint    := sl2[x+10];
                   end;
                if y = 2 then
                   begin
                panelx.helpkeyword := sl[x+20];
                panelx.hint    := sl2[x+20];
                   end;
               if odd(x) then
               panelx.color := oddColor;
               if not  odd(x)  then
               panelx.Color := evenColor;// TColor($420303);// TColor($510400);
                if length(panelx.helpkeyword) < 6 then
                panelx.font.size := strtoint(ReadINIstr('Main','FontSize'))
                else
                panelx.font.size := strtoint(ReadINIstr('Main','FontSize'))-2;
            end;

        end;
   end;


procedure TForm1.FormPaint(Sender: TObject);
var
  b: TBrush;
  rc: TRect;
begin

  // Create a brush and assign your tiled bitmap to it
  b := TBrush.Create;
  try
    // Ensure ImgBrush contains the bitmap you want to tile
    // use a Timage to store the bitmap so there is no
    // loading at run time in system startup on linux mint
    // as this causes errors
    b.Bitmap := image1.Picture.Bitmap;

    // Set the form's canvas brush to your tiled brush
    Canvas.Brush := b;

    // Define the rectangle covering the entire form
    rc := Rect(0, 0, Self.Width, Self.Height);

    // Fill the form with the tiled pattern
    if sender.ClassName = 'TForm1' then
    tform(sender).Canvas.FillRect(rc)
     else

    tpanel(sender).canvas.FillRect(rc)   ;

  finally
    b.Free;
  end;

end;

procedure TForm1.Image2Click(Sender: TObject);
begin

end;

procedure TForm1.MenuItem1Click(Sender: TObject);
begin
     application.terminate;
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
     panel2.visible := not panel2.visible;
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
begin

end;

procedure TForm1.Panel10Click(Sender: TObject);
var
  INI: Tinifile;
begin
 fontdialog1.Font := form1.font;
 if fontdialog1.Execute then
        begin
 form1.Font := fontdialog1.font;
 INI := tinifile.Create(form1.hint);
 ini.WriteString('Main','FontSize',inttostr(fontdialog1.Font.Size));
       end;
// sent a click action to the refresh event handler
// to redraw all buttons
 if Assigned(panel7.OnClick) then
  panel7.OnClick(panel7);
end;

procedure TForm1.Panel11Click(Sender: TObject);
var
  sl: tstringlist;
  x: integer;
begin
 // lazres settings.lrs settingsMint.ini settingsArch.ini
 form1.Paint;
 form1.canvas.Brush.Style := bsClear;
  sl :=  executersynccommand('lazres settings.lrs settingsMint.ini settingsArch.ini',sl);
 for x := 0 to sl.count-1 do
     form1.Canvas.TextOut(50,50*x,sl[x]);
  sl.Destroy;
end;

procedure TForm1.Panel12Click(Sender: TObject);
begin
  form3.Show;
end;

procedure TForm1.Panel13Click(Sender: TObject);
var
  x,oldsize: integer;
  sl:        tstringlist;
begin
 sl := tstringlist.Create;
  form1.canvas.Brush.Style := bsClear;
       x := FileUtil.FileSize(getcurrentdir+'/'+extractfilename(application.exename));
       x := x div 1000000;
       oldsize := x;
        form1.Canvas.TextOut(50,50,'Starting build ... timer started, current size is '+inttostr(x)+'M ... needs lazbuild to work.');
        form1.canvas.TextOut(50,100,'Executable name is '+ExtractFileName(Application.ExeName));
        form1.canvas.textout(50,150,'Only works if program is executed in its own directory otherwise, path issues occur.');
        executeCmdDetach('lazbuild --build-mode=Release '+extractfilename(application.exename)+'.lpi',sl);

       timer2.enabled := true;
end;

procedure TForm1.Panel15Click(Sender: TObject);
begin
      // Ini.WrString('Main', 'ConfigLock', 'pluma');
           WriteINIstr('Main','ConfigLock','1');
           popupmenu1.autopopup := false;
        showmessage('Config Lock has been set. To unlock, in a text editor, go to the settingsMint.ini  ( or settingsArch.ini ) in the users .config/'+extractfilename(application.exename)+' directory ( not this programs ) and change ConfigLock to 0 ( hint use the Edit INI, on this bar, if you clicked it by mistake.');
end;



procedure TForm1.Panel1Click(Sender: TObject);
begin

end;

procedure TForm1.Panel1Paint(Sender: TObject);
var
//  b: TBrush;
  r: TRect;
begin
    R := tpanel(sender).ClientRect;

  // Fill with gradient from clBlue to clWhite, vertical direction
  if tpanel(sender).tag = 0 then
  tpanel(sender).Canvas.GradientFill(R, clBlack, clmaroon, gdVertical)
  else
  tpanel(sender).Canvas.GradientFill(R, clMaroon, clBlack, gdVertical)  ;
  tpanel(sender).canvas.Brush.Style := bsClear;
 //label1.caption := tpanel(sender).Caption;

 tpanel(sender).canvas.TextOut(0,0,tpanel(sender).helpkeyword);

end;

procedure TForm1.Panel2Click(Sender: TObject);
begin
  application.terminate;
end;

procedure TForm1.Panel4Click(Sender: TObject);
var
  sl: tstringlist;
  x: integer;
begin
 sl := tstringlist.create;
 sl.LoadFromFile( form1.hint);
 form1.Paint;
 form1.canvas.Brush.Style := bsClear;
     for x := 1 to sl.count-1 do
    begin
     if x < sl.Count then // just a check if top does have lines

           begin
              if x < 14  then
 form1.Canvas.TextOut(50,50*x,sl[x]);

              if (x>13) and (x < 28) then
          form1.Canvas.TextOut(350,50*(x-13),sl[x]);
              if (x> 27) and (x< 42)    then
            form1.Canvas.TextOut(650,50*(x-27),sl[x]);
               if (x> 41) and (x< 56)    then
            form1.Canvas.TextOut(950,50*(x-41),sl[x]);
               if x > 55 then
              form1.Canvas.TextOut(1250,50*(x-55),sl[x]);
           end;

    end;
end;

procedure TForm1.Panel5Click(Sender: TObject);
var
  sl: tstringlist;
  ini: tinifile;
  s: string;
begin
 // gnome-terminal -- bash -c
 {if not fileexists(form1.hint) then
  begin
  if findOSname('Mint') then
  if fileexists('settingsMint.ini') then
             begin
             mkdir('.config/'+ExtractFileName(Application.ExeName));
             fileutil.copyfile('settingsMint.ini',form1.hint);
             end;

  if findOSname('CachyOS') then
   if fileexists('settingsArch.ini') then
               begin
               mkdir('.config/'+ExtractFileName(Application.ExeName));
               fileutil.copyfile('settingsArch.ini',form1.hint);
               end;

  end;   }
//   then showmessage('exists');
 ini := tinifile.create(form1.hint);
 sl := tstringlist.create;
 s := Ini.ReadString('Main', 'EditINI', 'pluma');

   executeCmdDetach(s+' '+form1.hint,sl);
end;

procedure TForm1.Panel6Click(Sender: TObject);
begin
  panel2.Visible := not panel2.visible;
end;

function TForm1.createOptionButton(bName,bCap: string; panParent: tpanel;col: integer): tPanel;
var
  panelOpt: tpanel;
begin
  //
  panelOpt := tpanel.Create(panParent) ;
 panelOpt.parent := panParent;
 panelOpt.caption := bCap;
 if length(bCap) < 7 then
  panelOpt.font.Size := strtoint(ReadINIstr('Main','FontSize'))
 else
 panelopt.font.size := strtoint(ReadINIstr('Main','FontSizeSmall'));
 panelOpt.align  := alRight;
 if col = 1 then
 panelOpt.color := clMaroon;
 if col = 2 then
 panelOpt.color := clNavy;
 panelOpt.width :=  strtoint(ReadINIstr('Main','ButtonWidth'));
 //panelopt.Font := form1.font;
 //panelHide.OnClick := @panel6click;
 result := panelOpt;
end;

procedure TForm1.Panel7Click(Sender: TObject);
var
  i: Integer;
  Item: TControl;
  panelx,panely,panelExit,panelRefresh,panelEditINI,
    panelHide,panelCon,panelDesk,panelFont,
    panelBuild,panelLazRes,panelCalc,panelLock: tpanel;
  FoundComponent: TComponent;
begin
 if readinistr('Main','ConfigLock') = '1' then
 begin
 showmessage('Config has been locked by Admin.');
 exit;
 end;
 //FoundComponent: TComponent;
 FoundComponent := FindComponent('panelold');
   if Assigned(FoundComponent) then
    tpanel(foundcomponent).Destroy;
   panel1.Visible := false;
   panel1.Name := 'panelold';

  panelx := tpanel.Create(form1);
  panelx.Parent := form1;
   panelx.Height := strtoint(ReadINIstr('Main','ButtonHeight'))*4;
   panelx.color := $00212128;
   panelx.Align := alBottom;
  panelx.Name := 'panel1';
  createpanels;
   panel2 := tpanel.Create(panelx) ;
 panel2.parent := panelx;
 //panely.name   := 'panel2';
 panel2.Color := $000F0F53;
 panel2.align  := albottom;
 panel2.Height := strtoint(ReadINIstr('Main','ButtonHeight'));

 panelExit :=  createOptionButton('panelExit','Exit',panel2,2);
 panelExit.OnClick := @panel2click;

  panelRefresh :=  createOptionButton('panelRefresh','Refresh',panel2,1);
 panelRefresh.OnClick := @panel7click;

  panelEditINI := createOptionButton('panelEditINI','Edit INI',panel2,2);
 panelEditINI.OnClick := @panel5click;

  panelHide := createOptionButton('panelHide','Hide Conf',panel2,1);
 panelHide.OnClick := @panel6click;
        // contact panel
  panelCon := createOptionButton('panelCon','Contact',panel2,2);
 panelCon.OnClick := @panel8click;

 panelDesk := createOptionButton('panelDesk','Desk Mode',panel2,1);
 panelDesk.onclick := @panel9click;

 panelFont :=  createOptionButton('panelFont','Font',panel2,2);
 panelFont.onclick := @panel10click;

  panelLazRes :=  createOptionButton('panelLazRes','LazRes',panel2,1);
 panelLazRes.onclick := @panel11click;

  panelLazRes :=  createOptionButton('panelCalc','ProCalc',panel2,2);
 panelLazRes.onclick := @panel12click;

   panelLazRes :=  createOptionButton('panelBuild','Build',panel2,1);
 panelLazRes.onclick := @panel13click;
 panelLock :=  createOptionButton('panelLock','Lock',panel2,2);
 panelLock.onclick := @panel15click;
end;

procedure TForm1.Panel8Click(Sender: TObject);
begin
 //  tpanel(sender).width := 850;    mob 61 413 830 988
  showmessage('Licensed under GPL3. Created using Lazarus 4.2 on 14 September 2026. Email ven.vajra@protonmail.com ');
end;

procedure TForm1.Panel9Click(Sender: TObject);
begin
  panel1.Visible := false;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
var
  sl: tstringlist;
  x: integer;

begin
  sl := tstringlist.create;
   sl :=  executersynccommand('top -b -n 1',sl);
 if findOSname('CachyOS') then //'CachyOS') then
   begin
     //  form3.memo1.Visible := true;
       form4.top := 0;
       form4.left := 0;
       form4.Width := screen.width;
       form4.Height := form1.Height -panel1.height;
       form4.show;
      form4.memo1.text := sl.Text;
      exit;
   end;

  form1.Paint;
   form1.canvas.Brush.Style := bsClear;

    for x := 1 to 14 do
    begin
     if x < sl.Count then // just a check if top does have lines

     if odd(x) then
     form1.canvas.Font.Color := CLLime
     else
     form1.Canvas.font.color := clYellow;
 form1.Canvas.TextOut(50,50*x,sl[x]);
     end;
   form1.Canvas.TextOut(1150,50,form1.hint);
   // end;
 sl.destroy;
end;

procedure TForm1.Timer2Timer(Sender: TObject);
var
  sl: tstringlist;
  x,i: integer;
  s,str,s2: string;
begin
 sl := tstringlist.create;
 i := 0;
 form1.paint;
 form1.canvas.Brush.Style := bsClear;
 form1.canvas.Font.Size := 10;
       s :=   extractfilename(application.exename);
      s2 := s[1];  // get the first characer in the build file
                  // to do a list using ls of the dir to see
                  // relevant files
    sl :=  executersynccommand('ls -lh '+s2+'*',sl);
  for x :=  sl.Count-1 downto 1 do
    begin
     s :=   extractfilename(application.exename);
     str :=  getlasttoken(sl[x],' ');

    //. if str = s then
    if x < 20 then
  form1.Canvas.TextOut(50,40*x,stripfirsttoken(sl[x],' '));
    if x > 19 then
            begin
           i := i +1;

   form1.Canvas.TextOut(1050,40*i,stripfirsttoken(stripfirsttoken(sl[x],' '),' '));
             end;
    end;
 // form1.Canvas.TextOut(50,550,'Done !!! '+extractfilename(application.exename));
  timer2.Enabled := false;
  sl.destroy;
end;

procedure TForm1.TimerArchTimer(Sender: TObject);
begin
  form1.width := screen.width;
 // showmessage('path is '+form1.hint);
  if form1.Width = screen.width then
  timerArch.Enabled := false;
end;
  initialization
    {$I settings.lrs}

end.

