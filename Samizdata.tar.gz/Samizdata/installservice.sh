#!/usr/bin/env bash
set -euo pipefail

# --- Config ---
UNIT_NAME="samizdata.service"
DESC="Samizdata service"
EXEC_START="/usr/bin/samizdata"
RESTART="on-failure"
WANTED_BY="graphical-session.target"
PART_OF="graphical-session.target"

# --- Create the file ---
UNIT_DIR="$HOME/.config/systemd/user"
UNIT_FILE="$UNIT_DIR/$UNIT_NAME"

mkdir -p "$UNIT_DIR"

cat > "$UNIT_FILE" <<EOF
[Unit]
Description=$DESC
PartOf=$PART_OF

[Service]
ExecStart=$EXEC_START
Restart=$RESTART

[Install]
WantedBy=$WANTED_BY
EOF

chmod 644 "$UNIT_FILE"

# --- Reload & enable ---
systemctl --user daemon-reload
systemctl --user enable "$UNIT_NAME"
systemctl --user start "$UNIT_NAME"

echo "Done. $UNIT_NAME is enabled and running."
systemctl --user status "$UNIT_NAME"   
