unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ShellCtrls, ComCtrls,
  ExtCtrls, StdCtrls, strbox3,lazfileutils;

type
  TMyDataRec = record
        colo: Tcolor;
        boolio: Boolean;   // true for dir false for file
  end;

type

  { TForm1 }

  TForm1 = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    ListView1: TListView;
    ListView2: TListView;
    Panel1: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    Panel4: TPanel;
    Panel5: TPanel;
    Panel6: TPanel;
    procedure FormCreate(Sender: TObject);
    procedure ListView1Click(Sender: TObject);
    procedure ListView1CustomDrawItem(Sender: TCustomListView; Item: TListItem;
      State: TCustomDrawState; var DefaultDraw: Boolean);
    procedure ListView2Click(Sender: TObject);
    procedure Panel1Click(Sender: TObject);
    procedure Panel4Click(Sender: TObject);

  private
     procedure PanelClick(Sender: TObject);

   procedure UpdateListView(sl: tstringlist;listviewX: tlistview);
    procedure CreateButtons;
    procedure CreateDirAndCopy(fdStrS,fdStrD: string);
  public

  end;

var
  Form1: TForm1;
   const
   programStr = 'test';

implementation

{$R *.lfm}

{ TForm1 }


procedure TForm1.FormCreate(Sender: TObject);
var
  sl: tstringlist;
  Node: TTreeNode;
  x: integer;
  s: string;
begin
 form1.left := 0;
 form1.top  := 0;
 form1.width := screen.width;
 form1.height := screen.height;
 panel5.width := screen.width div 2;
 label1.Caption := getcurrentdir;
 label2.caption := getcurrentdir;
 CreateButtons;

  sl := tstringlist.create;
   sl := DirectoryStringList(getcurrentdir);
   //sl.Sort;
   // Node := TreeView1.Items.Add(nil, '..Parent');
      for x := 0 to sl.count-1 do
  // for x := 0 to 10 do
     begin
     s := ExcludeTrailingPathDelimiter(sl[x]);
     s := getlasttoken(s,'/');

   //  treeview1.Items.Add(node,s);
     end;
  sl := DirsAndFilesStringList(getcurrentdir,false);
   updatelistview(sl,listview1);
   updatelistview(sl,listview2);
end;
procedure TForm1.CreateDirAndCopy(fdStrS,fdStrD: string);
var
  sl: tstringlist;
begin
     sl := tstringlist.Create;
     // ( are we copying a dir not a file )
                      // and check if we have it in the destination if not create it
    if not directoryexists(fdStrd) and directoryexists(fdStrS) then
              //  mkdir (fdstrd);
                forcedirectories(fdstrd);

   sl := executersynccommand('cp -rv ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''',sl);
  // sl := executersynccommand( 'cp -rv '  + fdStrS  + ' '  + fdStrD ,sl);
        // display files copied
       // showmessage(sl.Text);
       IF SL.Count > 0 THEN
                   begin
                                   sl :=  DirsAndFilesStringList(label2.caption,false);
                  updatelistview(sl,listview2);
                  end;

end;

procedure TForm1.PanelClick(Sender: TObject);
var
  s,fdStrS,fdStrD: string;
  sl: tstringlist;
  x,oldsize: integer;
   //Ctrl: TWinControl;


begin
  //Ctrl := Screen.ActiveControl;   // or Form1.ActiveControl
  {if Assigned(Ctrl) then
              begin
    ShowMessage('Focused: ' + Ctrl.Name);
    exit;
              end;    }

     sl := tstringlist.Create;
    s := tpanel(sender).caption;
     if s = 'Copy' then
                  begin
                  if listview1.focused = true then
                              begin
    fdStrS  := label1.Caption+'/'+listview1.Selected.caption;
    fdStrD := label2.caption+'/'+listview1.selected.caption;
                              end;
                   if listview2.focused = true then
                              begin
    fdStrS  := label2.Caption+'/'+listview2.Selected.caption;
    fdStrD := label1.caption+'/'+listview2.selected.caption;
                              end;

    CreateDirAndCopy(fdStrS,fdStrD);
                 end;
    // check first to see if dest dir exists in the source
    // ( are we copying a dir not a file )
                      // and check if we have it in the destination if not create it
 {   if not directoryexists(fdStrd) and directoryexists(fdStrS) then
              //  mkdir (fdstrd);
                forcedirectories(fdstrd);

   sl := executersynccommand('cp -rv ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''',sl);
  // sl := executersynccommand( 'cp -rv '  + fdStrS  + ' '  + fdStrD ,sl);
        // display files copied
       // showmessage(sl.Text);
       IF SL.Count > 0 THEN
                   begin
                                   sl :=  DirsAndFilesStringList(label2.caption,false);
                  updatelistview(sl,listview2);
                  end;

                  end;  }
  end;

procedure TForm1.CreateButtons;
var
  x:      integer;
  btnPnl:  tpanel;
  sl: tstringlist;
begin
   sl := tstringlist.Create;
   for x := 0 to 5 do
         begin
     if x = 5 then
      sl.Add('Copy');
     if x = 4 then
      sl.Add('Copy to Date');
     if x = 3 then
      sl.Add('Make Dir');
     if x = 2 then
      sl.Add('Rename');
     if x = 1 then
      sl.Add('Delete');
      if x = 0 then
      sl.Add('Archive');

    //else
   // sl.Add('copy'+inttostr(x));
   //Process.CommandLine := 'cp -r ' + '''' + fdStrS + '''' + ' ' + '''' + fdStrD + '''';
         end;
   for x := 0 to 5 do
           begin

             btnPnl := tpanel.Create(form1.Panel3);
             if odd(x) then
              btnPnl.Color := clBlack;
             btnPnl.parent := form1.panel3;
             btnPnl.Caption := sl[x];
             btnPnl.Align   := alLeft;
             btnPnl.OnClick := @panelclick;
           end;
   sl.destroy;
end;



procedure TForm1.ListView1Click(Sender: TObject);
var
   Node: TTreeNode;
   sl: tstringlist  ;
begin
   if listview1.Selected.Caption = '..Parent' then
    begin
      sl := tstringlist.create;

      chdir(GetParentDir(getcurrentdir));
      label1.Caption := getcurrentdir;
      sl := DirsAndFilesStringList(getcurrentdir,false);
      updatelistview(sl,listview1);

      exit;
    end;
   if (tcolor(listview1.Selected.Data) = clTeal) and
   fileisreadable(listview1.Selected.caption) then   // it is a directory
         begin
           if label1.Caption <> '/' then
        label1.Caption := label1.caption+'/'+listview1.Selected.caption
        else
        label1.Caption := '/'+listview1.Selected.caption;
       sl := tstringlist.create;
       if directoryexists(getcurrentdir+'/'+listview1.selected.caption) then
        chdir(getcurrentdir+'/'+listview1.selected.caption)  else

    showmessage('Not found '+ getcurrentdir+'/'+listview1.Selected.caption);

     sl := DirsAndFilesStringList(getcurrentdir,false);
   updatelistview(sl,listview1);
   sl.destroy;
   end;

end;

procedure TForm1.ListView1CustomDrawItem(Sender: TCustomListView;
  Item: TListItem; State: TCustomDrawState; var DefaultDraw: Boolean);
var
  rct: trect;
begin
    DefaultDraw := False;

   sender.canvas.Brush.Style := bsClear;
  if tcolor(item.data) = clMaroon then
        Sender.Canvas.brush.Color :=  clnavy;//$00431C43;
  if tcolor(item.data) = clTeal then
         Sender.Canvas.brush.Color := $001A361A;
     if item.caption = '..Parent' then
         Sender.Canvas.brush.Color := clBlack;
     rct := Item.DisplayRect(drBounds);


   Sender.Canvas.FillRect(rct);
  // Draw the caption text
  Sender.Canvas.Font.Color := clWhite;
  sender.canvas.font.Size := 12;
  Sender.Canvas.TextOut(rct.Left + 2, rct.Top, Item.Caption);

end;

procedure TForm1.ListView2Click(Sender: TObject);
var
   Node: TTreeNode;
   sl: tstringlist  ;
begin
   if listview2.Selected.Caption = '..Parent' then
    begin
      sl := tstringlist.create;

      chdir(GetParentDir(getcurrentdir));
      label2.Caption := getcurrentdir;
      sl := DirsAndFilesStringList(getcurrentdir,false);
      updatelistview(sl,listview2);

      exit;
    end;
   if (tcolor(listview2.Selected.Data) = clTeal) and
   fileisreadable(listview2.Selected.caption) then   // it is a directory
         begin
             if label2.Caption <> '/' then
         label2.Caption := label2.caption+'/'+listview2.Selected.caption
        else
        label2.Caption := '/'+listview2.Selected.caption;

       sl := tstringlist.create;
       if directoryexists(getcurrentdir+'/'+listview2.selected.caption) then
        chdir(getcurrentdir+'/'+listview2.selected.caption)  else

    showmessage('Not found '+ getcurrentdir+'/'+listview2.Selected.caption);

     sl := DirsAndFilesStringList(getcurrentdir,false);
   updatelistview(sl,listview2);
   sl.destroy;
   end;

end;

procedure TForm1.Panel1Click(Sender: TObject);
begin
     application.terminate;
end;

procedure TForm1.Panel4Click(Sender: TObject);
begin
  application.terminate;
end;


procedure TForm1.UpdateListView(sl: tstringlist;listviewX: tlistview);
var
    colo: tcolor;
    x: integer;
    s: string;
      Item: TListItem;

begin
      listviewx.items.Clear;
       Item := ListViewx.Items.Add;
       item.Caption := '..Parent';
                       for x := 0 to sl.count-1 do

                               begin
                               s := ExcludeTrailingPathDelimiter(sl[x]);
                               //// il := tstringlist.Create;
                               if sl[x] <> s then               begin
                                            //  s := uppercase(s) ;
                                               colo := clTeal;
                                                          end
                                                          else
                                                          colo := clMaroon;
                               s := getlasttoken(s,'/');
                              // listview1.Items.ad;


                              Item := ListViewx.Items.Add;
                              item.Data := pointer(colo); //keeps colors for
                                                          // directorys Teal
                                                          // files      Maroon
                             Item.Caption := s;
                              // listview1.Items.Add(s);
                               end;
end;






{ --- Handle ".." selection to navigate up --- }

//TTreeView(ShellTreeView1).OnAddition := @ShellTreeView1OnAddition;
end.

